(function () {
  const cfg = window.COMPANY_CFG;
  let companies = [];
  let master = (cfg.komoditas || []).slice();   // master komoditas [{id, name}]
  let selectedKomoditas = [];                    // id komoditas terpilih di form

  const $ = (id) => document.getElementById(id);

  const STATUS_CLASS = {
    'Belum Dihubungi': 'b-gray',
    'Sudah Dihubungi': 'b-success',
    'Follow Up':       'b-warning',
    'Tertarik':        'b-info',
    'Tidak Tertarik':  'b-danger',
  };

  // Escape HTML: WAJIB tiap nyisipin data user ke innerHTML,
  // kalau tidak, nama perusahaan berisi <script> bisa jalan (XSS).
  function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  // Bandingkan teks tanpa peduli huruf besar/kecil dan spasi ganda.
  const norm = (s) => String(s ?? '').replace(/\s+/g, ' ').trim().toUpperCase();
  // Cari nilai di list yang sama (tak peka huruf); kembalikan bentuk dari list, atau null.
  const matchCI = (list, v) => (list || []).find((x) => norm(x) === norm(v)) ?? null;

  function toast(title, msg, type = 'success') {
    const icons = { success: '✓', error: '✕', warning: '!' };
    const div = document.createElement('div');
    div.className = 'toast t-' + type;
    div.innerHTML =
      `<div class="icon">${icons[type] || 'ℹ'}</div>` +
      `<div class="body"><div class="title">${esc(title)}</div><div class="msg">${esc(msg)}</div></div>`;
    let host = $('toast-host');
    if (!host) {
      host = document.createElement('div');
      host.id = 'toast-host';
      host.className = 'toast-host';
      document.body.appendChild(host);
    }
    host.appendChild(div);
    setTimeout(() => div.remove(), 3200);
  }

  const openModal  = (id) => $(id).classList.add('open');
  const closeModal = (id) => $(id).classList.remove('open');

  // Ekspos ke step 3b (file yang sama, dilanjut di bawah)
  window.CompanyUI = { cfg, $, esc, toast, openModal, closeModal, STATUS_CLASS,
    getCompanies: () => companies, reload: loadData };

  /* ---------- Ambil data dari server ---------- */
  async function loadData() {
    try {
      const res = await fetch(cfg.urls.data, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
      });
      syncCsrf(res);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      companies = json.data || [];
      fillKomoditasFilter();
      render();
    } catch (e) {
      $('tbody-perusahaan').innerHTML =
        '<tr><td colspan="11">Gagal memuat data. Coba refresh halaman.</td></tr>';
      console.error(e);
    }
  }

  /* ---------- Filter komoditas (dinamis dari data) ---------- */
  function fillKomoditasFilter() {
    const sel = $('filter-komoditas');
    const cur = sel.value;
    const vals = [...new Set(companies.flatMap((c) => (c.komoditas || []).map((k) => k.name)))]
      .sort((x, y) => x.localeCompare(y, 'id'));
    sel.innerHTML = '<option value="">Semua Komoditas</option>' +
      vals.map((v) => `<option>${esc(v)}</option>`).join('');
    sel.value = vals.includes(cur) ? cur : '';
  }

  // Komoditas satu perusahaan sebagai badge; nama panjang dipotong (...), penuh di tooltip
  function komBadges(c) {
    const list = c.komoditas || [];
    if (!list.length) return '-';
    return '<div class="kom-badges">' + list.map((k) =>
      `<span class="badge b-purple" title="${esc(k.name)}">${esc(k.name)}</span>`).join('') + '</div>';
  }

  /* ---------- Render tabel ---------- */
  function render() {
    const q  = $('search-perusahaan').value.toLowerCase();
    const fk = $('filter-komoditas').value;
    const fs = $('filter-status').value;
    const fp = $('filter-provinsi').value;

    const list = companies.filter((c) => {
      if (fk && !(c.komoditas || []).some((k) => k.name === fk)) return false;
      if (fs && c.status !== fs) return false;
      if (fp && norm(c.provinsi) !== norm(fp)) return false;
      if (q) {
        const hay = [c.kode, c.name, (c.komoditas || []).map((k) => k.name).join(' '),
                     c.alamat, c.kota, c.provinsi,
                     c.kontak, c.email, c.telepon,
                     c.kontak2, c.email2, c.telepon2].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const tb = $('tbody-perusahaan');
    if (list.length === 0) {
      tb.innerHTML = '<tr><td colspan="11">' +
        (companies.length ? 'Tidak ada perusahaan yang cocok dengan filter.'
                          : 'Belum ada perusahaan.') + '</td></tr>';
      return;
    }

    tb.innerHTML = list.map((c) => `
      <tr>
        <td data-th="Kode"><span style="font-family:var(--font-mono);font-size:12px">${esc(c.kode)}</span></td>
        <td data-th="Nama"><div style="font-weight:600;min-width:140px">${esc(c.name)}</div></td>
        <td class="td-komoditas" data-th="Komoditas">${komBadges(c)}</td>
        <td data-th="Alamat"><div style="min-width:160px;max-width:220px;white-space:normal">${esc(c.alamat || '-')}</div></td>
        <td data-th="Kota">${esc(c.kota || '-')}</td>
        <td data-th="Provinsi">${esc(c.provinsi || '-')}</td>
        <td data-th="Kontak">${esc(c.kontak || '-')}</td>
        <td data-th="Telepon" style="white-space:nowrap">${esc(c.telepon || '-')}</td>
        <td data-th="E-mail">${c.email ? `<a href="mailto:${esc(c.email)}" style="color:inherit">${esc(c.email)}</a>` : '-'}</td>
        <td data-th="Status"><span class="badge ${STATUS_CLASS[c.status] || 'b-gray'}">${esc(c.status || '-')}</span></td>
        <td data-th="Aksi"><div class="row-actions">
          <button title="Detail" data-act="view" data-id="${c.id}">👁</button>
          ${cfg.isAdmin ? `
            <button title="Edit" data-act="edit" data-id="${c.id}">✎</button>
            <button title="Hapus" class="danger" data-act="delete" data-id="${c.id}">🗑</button>` : ''}
        </div></td>
      </tr>`).join('');
  }

  /* ---------- Event binding ---------- */
  ['search-perusahaan', 'filter-komoditas', 'filter-status', 'filter-provinsi']
    .forEach((id) => $(id).addEventListener('input', render));

  // Tutup modal: tombol [data-close], klik area gelap, tombol Esc
  document.addEventListener('click', (e) => {
    const closer = e.target.closest('[data-close]');
    if (closer) closeModal(closer.dataset.close);
    if (e.target.classList.contains('modal-backdrop')) e.target.classList.remove('open');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape')
      document.querySelectorAll('.modal-backdrop.open').forEach((m) => m.classList.remove('open'));
  });

  /* =====================================================================
     STEP 3b — BAGIAN TULIS (tambah / edit / detail / hapus)
     Cek hak akses yang sebenarnya ada di Controller; guard cfg.isAdmin
     di sini hanya supaya UI tidak membingungkan.
     ===================================================================== */
  let editingId = null;      // null = mode tambah
  let deletingId = null;
  let saving = false;

  // Kolom biasa. Komoditas (banyak) ditangani terpisah lewat selectedKomoditas.
  const FIELDS = ['name', 'provinsi', 'status', 'alamat', 'kota',
                  'kontak', 'telepon', 'email',
                  'kontak2', 'telepon2', 'email2', 'catatan'];

  const findById = (id) => companies.find((c) => Number(c.id) === Number(id));

  /* ---------- CSRF ----------
     regenerate = true -> token berubah setelah SETIAP POST yang lolos.
     Cookie CSRF bersifat HttpOnly (tidak terbaca JS), jadi token terbaru
     dikirim server lewat header respons (lihat BaseController) dan
     disimpan di cfg.csrfToken untuk request berikutnya. */
  function syncCsrf(res) {
    const t = res.headers.get(cfg.csrfHeader);
    if (t) cfg.csrfToken = t;
  }

  /* Tidak melempar untuk 4xx supaya pemanggil bisa baca message/errors. */
  async function post(url, formData) {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json',
        [cfg.csrfHeader]: cfg.csrfToken,
      },
      body: formData || new FormData(),
    });
    syncCsrf(res);
    let json = null;
    try { json = await res.json(); } catch (_) { /* respons bukan JSON */ }
    return { status: res.status, json };
  }

  /* ---------- Error per field ---------- */
  function clearErrors() {
    document.querySelectorAll('#company-form .form-field').forEach((f) => {
      f.classList.remove('invalid');
      const e = f.querySelector('.err');
      if (e) e.textContent = '';
    });
  }
  function setError(field, msg) {
    const input = $('fc-' + field);
    if (!input) return false;
    const wrap = input.closest('.form-field');
    wrap.classList.add('invalid');
    const e = wrap.querySelector('.err');
    if (e) e.textContent = msg;
    return true;
  }

  /* ---------- Dropdown Kabupaten/Kota bergantung provinsi ---------- */
  // cfg.wilayah = { "Jawa Barat": ["Kabupaten Bandung", ...], ... }
  function fillKota(provinsi, selected) {
    const sel = $('fc-kota');
    const provKey = matchCI(Object.keys(cfg.wilayah || {}), provinsi);
    const list = provKey ? cfg.wilayah[provKey] : [];

    if (!provinsi) {
      sel.innerHTML = '<option value="">— Pilih provinsi dulu —</option>';
      sel.disabled = true;
      return;
    }
    let html = '<option value="">— Pilih kabupaten/kota —</option>' +
      list.map((k) => `<option value="${esc(k)}">${esc(k)}</option>`).join('');

    // Data lama (ketikan bebas) yang tidak ada di daftar: tetap ditampilkan
    // supaya tidak hilang diam-diam; server mengizinkan bila tidak diubah.
    const kotaKey = matchCI(list, selected);          // 'Kota Bandung' lama -> 'KOTA BANDUNG'
    if (selected && !kotaKey) {
      html += `<option value="${esc(selected)}">${esc(selected)} (di luar daftar)</option>`;
    }
    sel.innerHTML = html;
    sel.disabled = false;
    sel.value = kotaKey || selected || '';
  }

  // Ganti provinsi -> daftar kota diganti & pilihan kota direset
  $('fc-provinsi').addEventListener('change', (e) => fillKota(e.target.value, ''));

  // Peringatan dev: provinsi di dropdown yang belum punya daftar kota
  // (artinya nama di CompanyModel::PROVINCE_CODES beda dengan Wilayah.php)
  [...$('fc-provinsi').options].forEach((o) => {
    if (o.value && !(cfg.wilayah && cfg.wilayah[o.value]))
      console.warn('Wilayah: provinsi tanpa daftar kota ->', o.value);
  });

  /* ---------- Pemilih komoditas (chip) ---------- */
  function renderChips() {
    const byId = new Map(master.map((k) => [k.id, k]));
    $('fc-komoditas').innerHTML = selectedKomoditas.length
      ? selectedKomoditas.map((id) => {
          const k = byId.get(id);
          return k
            ? `<span class="chip" title="${esc(k.name)}"><span class="chip-text">${esc(k.name)}</span>` +
              `<button type="button" class="chip-x" data-remove-kom="${id}" aria-label="Hapus ${esc(k.name)}">×</button></span>`
            : '';
        }).join('')
      : '<span class="chip-empty">Belum ada komoditas dipilih</span>';

    // Dropdown hanya menampilkan yang belum dipilih
    $('fc-komoditas-select').innerHTML = '<option value="">+ Tambah komoditas…</option>' +
      master.filter((k) => !selectedKomoditas.includes(k.id))
            .map((k) => `<option value="${k.id}">${esc(k.name)}</option>`).join('');
  }

  $('fc-komoditas-select').addEventListener('change', (e) => {
    const id = Number(e.target.value);
    if (id && !selectedKomoditas.includes(id)) selectedKomoditas.push(id);
    renderChips();
  });

  $('fc-komoditas').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-remove-kom]');
    if (!btn) return;
    const id = Number(btn.dataset.removeKom);
    selectedKomoditas = selectedKomoditas.filter((x) => x !== id);
    renderChips();
  });

  /* ---------- Tambah komoditas baru langsung dari form ---------- */
  function showNewKom(show) {
    $('kom-new-row').style.display = show ? 'flex' : 'none';
    $('kom-new-err').textContent = '';
    $('fc-kom-new-input').value = '';
    if (show) $('fc-kom-new-input').focus();
  }

  async function saveNewKom() {
    const name = $('fc-kom-new-input').value.trim();
    if (!name) { $('kom-new-err').textContent = 'Nama komoditas wajib diisi.'; return; }
    if (name.includes(',') || name.includes(';')) {
      $('kom-new-err').textContent = 'Nama komoditas tidak boleh mengandung koma atau titik koma.';
      return;
    }

    const btn = $('btn-kom-new-save');
    btn.disabled = true;
    try {
      const fd = new FormData();
      fd.append('name', name);
      const { status, json } = await post(cfg.urls.komoditasStore, fd);

      if (status === 200 && json && json.success) {
        const k = json.data;
        if (!master.some((m) => m.id === k.id)) master.push(k);
        master.sort((a, b) => a.name.localeCompare(b.name, 'id'));
        if (!selectedKomoditas.includes(k.id)) selectedKomoditas.push(k.id);
        renderChips();
        showNewKom(false);
        toast('Berhasil', 'Komoditas "' + k.name + '" ditambahkan.');
      } else if (status === 422 && json) {
        const msgs = Object.values(json.errors || {});
        $('kom-new-err').textContent = msgs[0] || json.message || 'Data tidak valid.';
      } else if (status === 403 && json && json.message) {
        $('kom-new-err').textContent = json.message;
      } else {
        $('kom-new-err').textContent = 'Gagal menyimpan (HTTP ' + status + '). Muat ulang halaman lalu coba lagi.';
      }
    } catch (e) {
      console.error(e);
      $('kom-new-err').textContent = 'Tidak bisa menghubungi server.';
    } finally {
      btn.disabled = false;
    }
  }

  $('btn-kom-new').addEventListener('click', () => showNewKom(true));
  $('btn-kom-new-cancel').addEventListener('click', () => showNewKom(false));
  $('btn-kom-new-save').addEventListener('click', saveNewKom);
  $('fc-kom-new-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); saveNewKom(); }   // jangan submit form perusahaan
  });

  /* ---------- Form tambah / edit ---------- */
  function openForm(id) {
    if (!cfg.isAdmin) { toast('Akses ditolak', 'Hanya Admin yang dapat mengubah data.', 'error'); return; }
    const c = id ? findById(id) : null;
    if (id && !c) { toast('Gagal', 'Data tidak ditemukan. Muat ulang halaman.', 'error'); return; }

    editingId = c ? c.id : null;
    clearErrors();
    $('company-form').reset();
    fillKota('', '');

    $('form-title').textContent = c ? 'Edit Perusahaan' : 'Tambah Perusahaan';
    $('form-sub').textContent = c
      ? c.kode
      : 'Kode dibuat otomatis (CMP-0001, dst.)';

    FIELDS.forEach((f) => {
      if (f === 'kota' || f === 'provinsi') return;   // diisi terpisah (cocokkan tanpa peduli huruf)
      const el = $('fc-' + f);
      if (el) el.value = c ? (c[f] ?? '') : '';
    });
    if (!c) $('fc-status').selectedIndex = 0;
    const provOpt = c ? matchCI([...$('fc-provinsi').options].map((o) => o.value).filter(Boolean), c.provinsi) : null;
    $('fc-provinsi').value = provOpt || '';
    fillKota(provOpt || '', c ? (c.kota || '') : '');

    selectedKomoditas = c ? (c.komoditas || []).map((k) => k.id) : [];
    showNewKom(false);
    renderChips();

    openModal('modal-form');
    $('fc-name').focus();
  }

  /* ---------- Simpan ---------- */
  async function saveForm(ev) {
    ev.preventDefault();
    if (saving) return;
    clearErrors();

    // Cek cepat di klien; yang menentukan tetap validasi server.
    let ok = true;
    const val = (f) => $('fc-' + f).value.trim();
    if (!val('name'))      { setError('name', 'Wajib diisi'); ok = false; }
    if (!selectedKomoditas.length) { setError('komoditas', 'Pilih minimal satu komoditas'); ok = false; }
    if (!val('provinsi'))  { setError('provinsi', 'Wajib dipilih'); ok = false; }
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (val('email') && !emailRe.test(val('email'))) {
      setError('email', 'Format e-mail tidak valid'); ok = false;
    }
    if (val('email2') && !emailRe.test(val('email2'))) {
      setError('email2', 'Format e-mail tidak valid'); ok = false;
    }
    if (!ok) { toast('Validasi gagal', 'Periksa field yang ditandai.', 'error'); return; }

    const fd = new FormData();
    FIELDS.forEach((f) => fd.append(f, val(f)));
    selectedKomoditas.forEach((id) => fd.append('komoditas_ids[]', id));

    const btn = $('btn-form-save');
    const oldLabel = btn.textContent;
    saving = true; btn.disabled = true; btn.textContent = 'Menyimpan...';

    try {
      const url = editingId ? cfg.urls.update + editingId : cfg.urls.store;
      const { status, json } = await post(url, fd);

      if (status === 200 && json && json.success) {
        closeModal('modal-form');
        toast('Berhasil', json.message || 'Tersimpan');
        await loadData();
      } else if (status === 422 && json) {
        let shown = false;
        Object.entries(json.errors || {}).forEach(([f, m]) => { if (setError(f, m)) shown = true; });
        toast('Validasi gagal',
          shown ? 'Periksa field yang ditandai.' : (json.message || 'Data tidak valid.'), 'error');
      } else if (status === 403 && json && json.message) {
        toast('Akses ditolak', json.message, 'error');
      } else if (status === 404) {
        closeModal('modal-form');
        toast('Gagal', 'Data sudah tidak ada.', 'error');
        await loadData();
      } else {
        // Termasuk 403 dari filter CSRF (respons HTML) dan 500
        toast('Gagal menyimpan',
          'Server menolak permintaan (HTTP ' + status + '). Muat ulang halaman lalu coba lagi.', 'error');
      }
    } catch (e) {
      console.error(e);
      toast('Gagal menyimpan', 'Tidak bisa menghubungi server.', 'error');
    } finally {
      saving = false; btn.disabled = false; btn.textContent = oldLabel;
    }
  }

  /* ---------- Detail ---------- */
  function openDetail(id) {
    const c = findById(id);
    if (!c) return;
    $('detail-title').textContent = c.name;   // textContent: aman dari XSS
    $('detail-sub').textContent = c.kode;

    const row = (label, html) =>
      `<div class="form-field"><label>${label}</label><div style="font-size:14px">${html}</div></div>`;
    const txt = (v) => (v ? esc(v) : '-');
    const mail = (v) => (v ? `<a href="mailto:${esc(v)}" style="color:inherit">${esc(v)}</a>` : '-');

    $('detail-body').innerHTML = `<div class="form-grid">
      <div class="form-field full"><label>Komoditas</label><div style="font-size:14px">${komBadges(c)}</div></div>
      ${row('Status', `<span class="badge ${STATUS_CLASS[c.status] || 'b-gray'}">${esc(c.status || '-')}</span>`)}
      ${row('Kota', txt(c.kota))}
      ${row('Provinsi', txt(c.provinsi))}
      <div class="form-field full form-section">Kontak 1</div>
      ${row('Nama Kontak 1', txt(c.kontak))}
      ${row('Nomor Telepon 1', txt(c.telepon))}
      ${row('E-mail 1', mail(c.email))}
      <div class="form-field full form-section">Kontak 2</div>
      ${row('Nama Kontak 2', txt(c.kontak2))}
      ${row('Nomor Telepon 2', txt(c.telepon2))}
      ${row('E-mail 2', mail(c.email2))}
      <div class="form-field full"><label>Alamat</label><div style="font-size:14px;white-space:pre-wrap">${txt(c.alamat)}</div></div>
      <div class="form-field full"><label>Catatan</label><div style="font-size:14px;white-space:pre-wrap">${txt(c.catatan)}</div></div>
    </div>`;

    const editBtn = $('btn-detail-edit');     // hanya ada untuk Admin
    if (editBtn) editBtn.onclick = () => { closeModal('modal-detail'); openForm(c.id); };
    openModal('modal-detail');
  }

  /* ---------- Hapus ---------- */
  function askDelete(id) {
    const c = findById(id);
    if (!c) return;
    deletingId = c.id;
    $('confirm-title').textContent = 'Hapus perusahaan?';
    $('confirm-msg').textContent =
      `"${c.name}" (${c.kode}) akan dihapus. Project terkait tidak ikut terhapus, ` +
      `hanya kehilangan tautan perusahaannya.`;
    openModal('modal-confirm');
  }

  async function confirmDelete() {
    if (deletingId === null || saving) return;
    const id = deletingId;
    const btn = $('btn-confirm-ok');
    saving = true; btn.disabled = true;
    try {
      const { status, json } = await post(cfg.urls.remove + id);
      closeModal('modal-confirm');
      if (status === 200 && json && json.success) {
        toast('Berhasil', json.message || 'Perusahaan dihapus');
      } else if (status === 404) {
        toast('Info', 'Data sudah tidak ada.', 'warning');
      } else if (status === 403 && json && json.message) {
        toast('Akses ditolak', json.message, 'error');
      } else {
        toast('Gagal menghapus',
          'Server menolak permintaan (HTTP ' + status + '). Muat ulang halaman lalu coba lagi.', 'error');
      }
      await loadData();
    } catch (e) {
      console.error(e);
      closeModal('modal-confirm');
      toast('Gagal menghapus', 'Tidak bisa menghubungi server.', 'error');
    } finally {
      saving = false; btn.disabled = false; deletingId = null;
    }
  }

  /* ---------- Event binding (bagian tulis) ---------- */
  // Delegation: tbody dirender ulang tiap filter, jadi listener di induknya.
  $('tbody-perusahaan').addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const id = btn.dataset.id;
    if (btn.dataset.act === 'view') openDetail(id);
    else if (btn.dataset.act === 'edit') openForm(id);
    else if (btn.dataset.act === 'delete') askDelete(id);
  });

  const addBtn = $('btn-add-company');        // hanya dirender untuk Admin
  if (addBtn) addBtn.addEventListener('click', () => openForm(null));

  $('company-form').addEventListener('submit', saveForm);
  $('btn-confirm-ok').addEventListener('click', confirmDelete);


  /* =====================================================================
     IMPORT DARI EXCEL
     ===================================================================== */
  let importFile = null;
  let importToken = null;

  function resetImportModal() {
    importFile = null;
    importToken = null;
    $('import-file').value = '';
    $('import-filename').textContent = 'Belum ada file dipilih';
    $('import-step-upload').style.display = '';
    $('import-step-preview').style.display = 'none';
    $('btn-import-check').style.display = '';
    $('btn-import-check').disabled = false;
    $('btn-import-check').textContent = 'Periksa File';
    $('btn-import-confirm').style.display = 'none';
    ['block-invalid', 'block-warnings', 'block-skipped', 'block-newkom', 'block-headerinfo']
      .forEach((id) => { $(id).style.display = 'none'; });
  }

  function fillImportList(blockId, listId, items) {
    if (!items || !items.length) { $(blockId).style.display = 'none'; return; }
    $(blockId).style.display = '';
    $(listId).innerHTML = items.map((t) => `<div>${esc(t)}</div>`).join('');
  }

  $('btn-open-import').addEventListener('click', () => {
    resetImportModal();
    openModal('modal-import');
  });

  $('import-drop').addEventListener('click', (e) => {
    if (e.target.tagName !== 'INPUT') $('import-file').click();
  });
  $('import-file').addEventListener('change', () => {
    const f = $('import-file').files[0];
    importFile = f || null;
    $('import-filename').textContent = f ? f.name : 'Belum ada file dipilih';
  });
  // Tarik-lepas file ke area upload
  ['dragover', 'dragleave', 'drop'].forEach((evt) => {
    $('import-drop').addEventListener(evt, (e) => e.preventDefault());
  });
  $('import-drop').addEventListener('drop', (e) => {
    const f = e.dataTransfer.files[0];
    if (f) {
      $('import-file').files = e.dataTransfer.files;
      importFile = f;
      $('import-filename').textContent = f.name;
    }
  });

  async function checkImportFile() {
    if (!importFile) { toast('Belum ada file', 'Pilih file .xlsx dulu.', 'error'); return; }

    const btn = $('btn-import-check');
    const oldLabel = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Memeriksa...';

    try {
      const fd = new FormData();
      fd.append('file', importFile);
      const { status, json } = await post(cfg.urls.importPreview, fd);

      if (status === 200 && json && json.success) {
        importToken = json.token;
        $('sum-valid').textContent = json.summary.valid;
        $('sum-skipped').textContent = json.summary.skipped;
        $('sum-invalid').textContent = json.summary.invalid;

        fillImportList('block-invalid', 'list-invalid',
          (json.invalid || []).map((r) => `Baris ${r.rows.join(', ')}: ${r.reason}`));
        fillImportList('block-warnings', 'list-warnings', json.warnings);
        fillImportList('block-skipped', 'list-skipped', json.skipped);
        fillImportList('block-newkom', 'list-newkom',
          (json.newKomoditas || []).map((n) => n.includes(',') ? `${n}  (mengandung koma — pastikan ini memang satu komoditas)` : n));
        fillImportList('block-headerinfo', 'list-unrecognized', json.headerInfo && json.headerInfo.unrecognized);

        $('import-step-upload').style.display = 'none';
        $('import-step-preview').style.display = '';
        btn.style.display = 'none';
        if (json.summary.valid > 0) {
          $('btn-import-confirm').style.display = '';
          $('btn-import-confirm').textContent = `Impor Sekarang (${json.summary.valid})`;
        } else {
          toast('Tidak ada data valid', 'Tidak ada baris yang bisa diimpor dari file ini.', 'error');
        }
      } else if (json && json.message) {
        toast('File ditolak', json.message, 'error');
      } else {
        toast('Gagal memeriksa file', 'Server menolak permintaan (HTTP ' + status + ').', 'error');
      }
    } catch (e) {
      console.error(e);
      toast('Gagal memeriksa file', 'Tidak bisa menghubungi server.', 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = oldLabel;
    }
  }

  async function confirmImport() {
    if (!importToken) return;
    const btn = $('btn-import-confirm');
    const oldLabel = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Mengimpor...';

    try {
      const fd = new FormData();
      fd.append('token', importToken);
      const { status, json } = await post(cfg.urls.importCommit, fd);

      if (status === 200 && json && json.success) {
        closeModal('modal-import');
        toast('Berhasil', json.message || 'Impor selesai');
        await loadData();
      } else if (json && json.message) {
        toast('Impor gagal', json.message, 'error');
      } else {
        toast('Impor gagal', 'Server menolak permintaan (HTTP ' + status + ').', 'error');
      }
    } catch (e) {
      console.error(e);
      toast('Impor gagal', 'Tidak bisa menghubungi server.', 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = oldLabel;
    }
  }

  $('btn-import-check').addEventListener('click', checkImportFile);
  $('btn-import-confirm').addEventListener('click', confirmImport);

  loadData();
})();