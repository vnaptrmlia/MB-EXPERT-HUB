<?php

namespace App\Libraries;

use App\Models\CompanyModel;
use App\Models\KomoditasModel;
use RuntimeException;

/**
 * Impor perusahaan dari Excel (.xlsx), dua tahap:
 *   1. mapHeaders() + buildRecords() + validate()  -> pratinjau, TIDAK menulis DB
 *   2. persist()                                    -> menulis semua baris valid, satu transaction
 *
 * Field tunggal yang dikenali: name, komoditas, alamat, kota, provinsi,
 * kontak, telepon, email, kontak2, telepon2, email2 (nama sama dengan
 * kolom/field di CompanyModel, supaya bisa langsung dipakai insert()).
 *
 * Satu sel komoditas = satu nama komoditas UTUH, tidak pernah dipotong
 * (keputusan produk: koma dan "dan" boleh jadi bagian nama komoditas).
 * Baris dengan nama perusahaan sama (tanpa peduli huruf besar/kecil dan
 * spasi) digabung jadi satu perusahaan; komoditasnya digabung juga.
 */
class CompanyImporter
{
    public const MAX_ROWS  = 1000;
    public const MAX_BYTES = 5 * 1024 * 1024;

    // Kolom yang muncul sekali per perusahaan (bukan per-kontak).
    private const SINGLE_FIELDS = ['name', 'komoditas', 'alamat', 'kota', 'provinsi'];
    // Kolom kontak: bisa muncul 2x (kontak 1 & 2). Nama family = nama field kontak 1.
    private const CONTACT_FIELDS = ['kontak', 'telepon', 'email'];

    /**
     * Cocokkan header ke nama field, berdasar kata kunci (tidak peka posisi
     * kolom maupun huruf besar/kecil), supaya tahan terhadap variasi judul
     * antar file Excel.
     */
    private function familyOf(string $normalizedHeader): ?string
    {
        if (in_array($normalizedHeader, ['no', 'no.', '#', 'nomor urut'], true)) {
            return 'ignore';
        }
        if (str_contains($normalizedHeader, 'komoditas')) {
            return 'komoditas';
        }
        if (str_contains($normalizedHeader, 'provinsi')) {
            return 'provinsi';
        }
        if (str_contains($normalizedHeader, 'kota') || str_contains($normalizedHeader, 'kabupaten')) {
            return 'kota';
        }
        if (str_contains($normalizedHeader, 'alamat')) {
            return 'alamat';
        }
        if (str_contains($normalizedHeader, 'importir')
            || str_contains($normalizedHeader, 'nama perusahaan')
            || $normalizedHeader === 'perusahaan'
            || $normalizedHeader === 'nama') {
            return 'name';
        }
        if (str_contains($normalizedHeader, 'email') || str_contains($normalizedHeader, 'mail')) {
            return 'email';
        }
        if (str_contains($normalizedHeader, 'telepon') || str_contains($normalizedHeader, 'telfon')
            || str_contains($normalizedHeader, 'hp') || str_contains($normalizedHeader, 'phone')) {
            return 'telepon';
        }
        if (str_contains($normalizedHeader, 'kontak')
            || str_contains($normalizedHeader, 'pic')
            || str_contains($normalizedHeader, 'penanggung jawab')) {
            return 'kontak';
        }
        return null; // tidak dikenali
    }

    private function normalizeHeader(string $h): string
    {
        return trim(preg_replace('/\s+/u', ' ', mb_strtolower((string) $h)));
    }

    /** Header eksplisit menyebut kontak/kolom KEDUA, mis. "Nama Kontak 2", "E-mail 2". */
    private function isExplicitSecond(string $rawHeader): bool
    {
        return (bool) preg_match('/(^|\D)2(\D|$)/', $rawHeader)
            || (bool) preg_match('/\bkedua\b/i', $rawHeader);
    }

    /**
     * @param  string[] $headerRow  Baris pertama sheet (header), apa adanya.
     * @return array{map: array<string,int>, ignored: array<int,string>, unrecognized: array<int,string>}
     */
    public function mapHeaders(array $headerRow): array
    {
        $map         = [];
        $queue       = ['kontak' => [], 'telepon' => [], 'email' => []];
        $ignored     = [];
        $unrecognized = [];

        foreach ($headerRow as $col => $raw) {
            $raw = trim((string) $raw);
            if ($raw === '') {
                continue;
            }
            $norm = $this->normalizeHeader($raw);
            $fam  = $this->familyOf($norm);

            if ($fam === null) {
                $unrecognized[] = $raw;
                continue;
            }
            if ($fam === 'ignore') {
                $ignored[] = $raw;
                continue;
            }

            if (in_array($fam, self::CONTACT_FIELDS, true)) {
                if ($this->isExplicitSecond($raw)) {
                    $key = $fam . '2';
                    if (isset($map[$key])) {
                        $unrecognized[] = $raw . ' (kolom ' . $fam . '2 sudah terisi dari kolom lain)';
                    } else {
                        $map[$key] = $col;
                    }
                } else {
                    $queue[$fam][] = $col;
                }
                continue;
            }

            // Field tunggal (name, komoditas, alamat, kota, provinsi)
            if (isset($map[$fam])) {
                $unrecognized[] = $raw . " (kolom '{$fam}' sudah terisi dari kolom lain)";
            } else {
                $map[$fam] = $col;
            }
        }

        // Selesaikan antrean kontak: kemunculan pertama -> field 1, kedua -> field 2.
        foreach (self::CONTACT_FIELDS as $fam) {
            $cols = $queue[$fam];
            if (! isset($map[$fam]) && isset($cols[0])) {
                $map[$fam] = $cols[0];
            }
            if (! isset($map[$fam . '2']) && isset($cols[1])) {
                $map[$fam . '2'] = $cols[1];
            }
            foreach (array_slice($cols, 2) as $extraCol) {
                $unrecognized[] = "Kolom ke-{$extraCol} (kelebihan kolom '{$fam}', diabaikan)";
            }
        }

        return ['map' => $map, 'ignored' => $ignored, 'unrecognized' => $unrecognized];
    }

    private function normName(string $s): string
    {
        return mb_strtoupper(trim(preg_replace('/\s+/u', ' ', $s)));
    }

    /**
     * Gabungkan baris data jadi daftar perusahaan (baris nama sama -> satu grup).
     * Baris yang namanya kosong TAPI ada isian lain ditandai baris bermasalah
     * tersendiri (tidak bisa digabung, tidak jelas ini perusahaan siapa).
     *
     * @param  array<string,int>       $map      Hasil mapHeaders()['map']
     * @param  array<int, array<int,mixed>> $dataRows  excelRowNumber => baris sel (indeks kolom 0-based)
     * @return array{groups: array<string, array<string,mixed>>, namelessRows: int[]}
     */
    public function buildRecords(array $map, array $dataRows): array
    {
        $get = static function (array $row, array $map, string $field): string {
            $col = $map[$field] ?? null;
            if ($col === null || ! array_key_exists($col, $row)) {
                return '';
            }
            return trim((string) $row[$col]);
        };

        $groups       = [];
        $namelessRows = [];

        foreach ($dataRows as $excelRow => $row) {
            $name = $get($row, $map, 'name');

            $allFields = array_merge(self::SINGLE_FIELDS, self::CONTACT_FIELDS, ['kontak2', 'telepon2', 'email2']);
            $anyValue  = false;
            foreach ($allFields as $f) {
                if ($get($row, $map, $f) !== '') {
                    $anyValue = true;
                    break;
                }
            }
            if (! $anyValue) {
                continue; // baris kosong total, lewati diam-diam
            }

            if ($name === '') {
                $namelessRows[] = $excelRow;
                continue;
            }

            $key = $this->normName($name);
            if (! isset($groups[$key])) {
                $groups[$key] = [
                    'name'        => $name, // nama tampilan: dari kemunculan pertama
                    'sourceRows'  => [],
                    'komoditas'   => [], // lower(name) => nama asli (kemunculan pertama)
                    'fields'      => array_fill_keys(
                        ['alamat', 'kota', 'provinsi', 'kontak', 'telepon', 'email', 'kontak2', 'telepon2', 'email2'],
                        ''
                    ),
                ];
            }

            $g                    = &$groups[$key];
            $g['sourceRows'][]    = $excelRow;

            foreach (['alamat', 'kota', 'provinsi', 'kontak', 'telepon', 'email', 'kontak2', 'telepon2', 'email2'] as $f) {
                if ($g['fields'][$f] === '') {
                    $v = $get($row, $map, $f);
                    if ($v !== '') {
                        $g['fields'][$f] = $v;
                    }
                }
            }

            $komodCell = $get($row, $map, 'komoditas');
            if ($komodCell !== '') {
                $komodCell = trim(preg_replace('/\s+/u', ' ', $komodCell));
                $lower     = mb_strtolower($komodCell);
                $g['komoditas'][$lower] ??= $komodCell;
            }
            unset($g);
        }

        return ['groups' => $groups, 'namelessRows' => $namelessRows];
    }

    private function validEmail(string $v): bool
    {
        return (bool) preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $v);
    }

    /**
     * @param  array<string, array<string,mixed>> $groups        Dari buildRecords()['groups']
     * @param  string[]                            $existingNamesUpper  Nama perusahaan yang SUDAH ada (huruf besar, trim)
     * @param  string[]                             $existingKomoditasLower  name(lower) komoditas yang sudah ada di master
     * @return array{
     *   valid: array<int, array<string,mixed>>,
     *   skipped: array<int, array<string,mixed>>,
     *   invalid: array<int, array<string,mixed>>,
     *   warnings: array<int, string>,
     *   newKomoditas: string[]
     * }
     */
    public function validate(array $groups, array $existingNamesUpper, array $existingKomoditasLower): array
    {
        $valid    = [];
        $skipped  = [];
        $invalid  = [];
        $warnings = [];
        $newKomod = []; // lower => nama asli

        $existingNamesUpper = array_map(fn ($n) => $this->normName($n), $existingNamesUpper);

        foreach ($groups as $g) {
            $rowsLabel = 'baris ' . implode(', ', $g['sourceRows']);
            $errors    = [];

            if ($g['komoditas'] === []) {
                $errors[] = 'Komoditas wajib diisi';
            }

            $prov       = $g['fields']['provinsi'];
            $provCanon  = $prov === '' ? null : Wilayah::canonicalProvinsi($prov);
            if ($prov === '') {
                $errors[] = 'Provinsi wajib diisi';
            } elseif ($provCanon === null) {
                $errors[] = "Provinsi tidak dikenali: '{$prov}'";
            }

            $kotaCanon = null;
            $kota      = $g['fields']['kota'];
            if ($kota !== '' && $provCanon !== null) {
                $kotaCanon = Wilayah::canonicalKota($provCanon, $kota);
                if ($kotaCanon === null) {
                    $errors[] = "Kota/kabupaten '{$kota}' tidak sesuai provinsi '{$provCanon}'";
                }
            }

            if ($errors !== []) {
                $invalid[] = [
                    'name'   => $g['name'],
                    'rows'   => $g['sourceRows'],
                    'reason' => implode('; ', $errors) . ' (' . $rowsLabel . ')',
                ];
                continue;
            }

            // Peringatan (tidak menggagalkan baris): e-mail format tidak valid -> dikosongkan.
            $email  = $g['fields']['email'];
            $email2 = $g['fields']['email2'];
            if ($email !== '' && ! $this->validEmail($email)) {
                $warnings[] = "{$g['name']}: e-mail 1 '{$email}' tidak valid, dikosongkan ({$rowsLabel})";
                $email = '';
            }
            if ($email2 !== '' && ! $this->validEmail($email2)) {
                $warnings[] = "{$g['name']}: e-mail 2 '{$email2}' tidak valid, dikosongkan ({$rowsLabel})";
                $email2 = '';
            }

            $existingCompany = in_array($this->normName($g['name']), $existingNamesUpper, true);

            $komoditasNames = array_values($g['komoditas']);
            foreach ($komoditasNames as $kn) {
                $lower = mb_strtolower($kn);
                if (! in_array($lower, $existingKomoditasLower, true)) {
                    $newKomod[$lower] ??= $kn;
                }
            }

            $record = [
                'name'      => $g['name'],
                'rows'      => $g['sourceRows'],
                'komoditas' => $komoditasNames,
                'fields'    => [
                    'alamat'   => $g['fields']['alamat'],
                    'kota'     => $kotaCanon ?? '',
                    'provinsi' => $provCanon,
                    'kontak'   => $g['fields']['kontak'],
                    'telepon'  => $g['fields']['telepon'],
                    'email'    => $email,
                    'kontak2'  => $g['fields']['kontak2'],
                    'telepon2' => $g['fields']['telepon2'],
                    'email2'   => $email2,
                ],
            ];

            if ($existingCompany) {
                $skipped[] = $record + ['reason' => 'Sudah ada di database'];
            } else {
                $valid[] = $record;
            }
        }

        return [
            'valid'        => $valid,
            'skipped'      => $skipped,
            'invalid'      => $invalid,
            'warnings'     => $warnings,
            'newKomoditas' => array_values($newKomod),
        ];
    }

    /**
     * Simpan semua baris valid: komoditas baru dibuat dulu, lalu tiap
     * perusahaan + pivot komoditasnya, semua dalam SATU transaction.
     *
     * @param  array<int, array<string,mixed>> $validRecords  Dari validate()['valid']
     * @return int Jumlah perusahaan yang berhasil ditambahkan
     *
     * @throws RuntimeException bila ada langkah yang gagal (transaction di-rollback oleh pemanggil)
     */
    public function persist(array $validRecords): int
    {
        $db = \Config\Database::connect();

        $komodModel = new KomoditasModel();
        $nameToId   = [];
        foreach ($komodModel->select('id, name')->findAll() as $k) {
            $nameToId[mb_strtolower($k['name'])] = (int) $k['id'];
        }

        // Buat komoditas baru yang belum ada di master.
        foreach ($validRecords as $r) {
            foreach ($r['komoditas'] as $kn) {
                $lower = mb_strtolower($kn);
                if (! isset($nameToId[$lower])) {
                    $newId = $komodModel->insert(['name' => $kn]);
                    if (! $newId) {
                        throw new RuntimeException("Gagal membuat komoditas '{$kn}': " . implode(' ', $komodModel->errors()));
                    }
                    $nameToId[$lower] = (int) $newId;
                }
            }
        }

        $companyModel = new CompanyModel();
        $count        = 0;

        foreach ($validRecords as $r) {
            $newId = $companyModel->insert(array_merge(['name' => $r['name']], $r['fields']));
            if (! $newId) {
                throw new RuntimeException("Gagal menyimpan perusahaan '{$r['name']}': " . implode(' ', $companyModel->errors()));
            }

            $pivotRows = [];
            foreach ($r['komoditas'] as $kn) {
                $pivotRows[] = ['company_id' => $newId, 'komoditas_id' => $nameToId[mb_strtolower($kn)]];
            }
            if ($pivotRows !== []) {
                $db->table('company_komoditas')->insertBatch($pivotRows);
            }

            $count++;
        }

        return $count;
    }
}