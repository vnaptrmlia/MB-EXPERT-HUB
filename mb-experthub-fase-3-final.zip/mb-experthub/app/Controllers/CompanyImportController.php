<?php

namespace App\Controllers;

use App\Libraries\CompanyImporter;
use App\Models\CompanyModel;
use App\Models\KomoditasModel;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

/**
 * Impor perusahaan dari Excel, dua tahap:
 *   POST perusahaan/import/preview -> baca & validasi, TIDAK menulis DB, simpan
 *                                      hasil valid ke file sementara, kembalikan token
 *   POST perusahaan/import/commit  -> tulis semua baris valid (token) dalam 1 transaction
 *   GET  perusahaan/import/template -> unduh contoh file .xlsx dengan header yang benar
 *
 * Admin saja. File sementara disimpan di writable/imports/{token}.json dan
 * TIDAK bisa diisi/diubah dari luar server (dibuat & dibaca sendiri oleh
 * controller ini), jadi commit tidak perlu memvalidasi ulang isinya.
 */
class CompanyImportController extends BaseController
{
    private const STAGE_DIR = WRITEPATH . 'imports/';
    private const STAGE_TTL = 3600; // detik; berkas sisa lebih tua dari ini dibuang saat preview

    public function preview()
    {
        if ($denied = $this->denyNonAdmin()) {
            return $denied;
        }

        $file = $this->request->getFile('file');
        if ($file === null || ! $file->isValid()) {
            return $this->badRequest('File tidak ditemukan atau gagal diunggah.');
        }
        if (strtolower($file->getClientExtension()) !== 'xlsx') {
            return $this->badRequest('Hanya file .xlsx yang didukung.');
        }
        if ($file->getSize() > CompanyImporter::MAX_BYTES) {
            return $this->badRequest('Ukuran file maksimal 5 MB.');
        }

        try {
            $spreadsheet = IOFactory::load($file->getTempName());
        } catch (\Throwable $e) {
            return $this->badRequest('File tidak bisa dibaca. Pastikan ini file Excel (.xlsx) yang valid.');
        }

        $sheet = $spreadsheet->getActiveSheet();
        $grid  = $this->readGridAsText($sheet);

        if ($grid === []) {
            return $this->badRequest('File kosong.');
        }

        $headerRow = array_shift($grid); // baris pertama = header; sisanya data, nomor Excel mulai baris 2
        $dataRows  = [];
        foreach ($grid as $i => $row) {
            $dataRows[$i + 2] = $row;
        }

        if (count($dataRows) > CompanyImporter::MAX_ROWS) {
            return $this->badRequest('Maksimal ' . CompanyImporter::MAX_ROWS . ' baris data per impor.');
        }

        $importer = new CompanyImporter();
        $mapped   = $importer->mapHeaders($headerRow);

        if (! isset($mapped['map']['name'])) {
            return $this->badRequest("Kolom nama perusahaan tidak ditemukan (cari header seperti 'Nama Importir' atau 'Nama Perusahaan').");
        }
        if (! isset($mapped['map']['komoditas'])) {
            return $this->badRequest("Kolom komoditas tidak ditemukan (cari header 'Komoditas' / 'Nama Komoditas').");
        }

        $built = $importer->buildRecords($mapped['map'], $dataRows);

        $existingNames = array_column(
            (new CompanyModel())->select('name')->findAll(),
            'name'
        );
        $existingKomoditasLower = array_map(
            'mb_strtolower',
            array_column((new KomoditasModel())->select('name')->findAll(), 'name')
        );

        $result = $importer->validate($built['groups'], $existingNames, $existingKomoditasLower);

        $this->gcStaleStageFiles();
        $token = bin2hex(random_bytes(16));
        $this->writeStage($token, $result['valid']);

        return $this->response->setJSON([
            'success' => true,
            'token'   => $token,
            'summary' => [
                'valid'   => count($result['valid']),
                'skipped' => count($result['skipped']),
                'invalid' => count($built['namelessRows']) + count($result['invalid']),
            ],
            'invalid' => array_merge(
                array_map(
                    static fn ($r) => ['rows' => [$r], 'reason' => 'Nama perusahaan kosong'],
                    $built['namelessRows']
                ),
                array_map(
                    static fn ($r) => ['rows' => $r['rows'], 'reason' => "{$r['name']}: {$r['reason']}"],
                    $result['invalid']
                )
            ),
            'skipped'      => array_map(static fn ($r) => $r['name'], $result['skipped']),
            'warnings'     => $result['warnings'],
            'newKomoditas' => $result['newKomoditas'],
            'headerInfo'   => [
                'ignored'      => $mapped['ignored'],
                'unrecognized' => $mapped['unrecognized'],
            ],
        ]);
    }

    public function commit()
    {
        if ($denied = $this->denyNonAdmin()) {
            return $denied;
        }

        $token = (string) $this->request->getPost('token');
        if (! preg_match('/^[0-9a-f]{32}$/', $token)) {
            return $this->badRequest('Token impor tidak valid.');
        }

        $validRecords = $this->readStage($token);
        if ($validRecords === null) {
            return $this->badRequest('Sesi impor sudah kedaluwarsa. Unggah ulang filenya.');
        }
        if ($validRecords === []) {
            return $this->badRequest('Tidak ada baris valid untuk diimpor.');
        }

        $db = \Config\Database::connect();
        $db->transStart();
        try {
            $count = (new CompanyImporter())->persist($validRecords);
        } catch (\Throwable $e) {
            $db->transRollback();
            $this->deleteStage($token);
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Gagal mengimpor: ' . $e->getMessage(),
            ]);
        }
        $db->transComplete();
        $this->deleteStage($token);

        if ($db->transStatus() === false) {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Gagal mengimpor data. Coba lagi.',
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => "{$count} perusahaan berhasil diimpor.",
        ]);
    }

    // Contoh file dengan header yang benar + satu baris contoh, supaya format kolom jelas.
    public function template()
    {
        if (session()->get('role') !== 'Admin') {
            return redirect()->to(site_url('perusahaan'))->with('error', 'Hanya Admin yang dapat mengunduh template.');
        }

        $headers = [
            'Nama Komoditas', 'Nama Importir', 'Alamat Importir', 'Kota Kab', 'Provinsi',
            'Nama Kontak 1', 'Nomor Telepon 1', 'E-mail',
            'Nama Kontak 2', 'Nomor Telepon 2', 'E-mail 2',
        ];
        $example = [
            'Elektronika', 'PT Contoh Sejahtera', 'Jl. Contoh No. 1', 'Kota Bandung', 'Jawa Barat',
            'Budi Santoso', '+628123456789', 'budi@contoh.co.id',
            '', '', '',
        ];

        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();
        $sheet->fromArray($headers, null, 'A1');
        $sheet->fromArray($example, null, 'A2');

        // Kolom telepon dipaksa format TEKS supaya '+62...' tidak berubah jadi angka.
        foreach (['F', 'G', 'J', 'K'] as $col) {
            $sheet->getStyle("{$col}2:{$col}1000")->getNumberFormat()->setFormatCode(NumberFormat::FORMAT_TEXT);
        }
        foreach (range(1, count($headers)) as $i) {
            $sheet->getColumnDimensionByColumn($i)->setWidth(22);
        }
        $sheet->getStyle('A1:K1')->getFont()->setBold(true);

        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');

        $this->response->setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $this->response->setHeader('Content-Disposition', 'attachment; filename="template-import-perusahaan.xlsx"');

        ob_start();
        $writer->save('php://output');
        $this->response->setBody(ob_get_clean());

        return $this->response;
    }

    /* ------------------------------------------------------------------ */

    /**
     * Ambil seluruh sheet sebagai teks (bukan angka), supaya nomor telepon
     * yang tersimpan sebagai teks di Excel ('+62...') tidak berubah jadi
     * angka/notasi ilmiah. Baris & kolom kosong di ujung tidak disertakan.
     *
     * @return array<int, array<int, string>>
     */
    private function readGridAsText($sheet): array
    {
        $highestRow = $sheet->getHighestDataRow();
        $highestCol = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($sheet->getHighestDataColumn());

        $grid = [];
        for ($r = 1; $r <= $highestRow; $r++) {
            $row = [];
            for ($c = 1; $c <= $highestCol; $c++) {
                $cell = $sheet->getCell([$c, $r]); // getCellByColumnAndRow() sudah dihapus di PhpSpreadsheet 5.x
                $val  = $cell->getValue();

                if ($val === null) {
                    $row[$c - 1] = '';
                    continue;
                }
                // Sel numerik (mis. telepon tanpa format Teks di Excel) tetap
                // dibaca, tapi diberi tanda supaya kelihatan di pratinjau/warning.
                if ($cell->getDataType() === DataType::TYPE_NUMERIC) {
                    $row[$c - 1] = rtrim(rtrim(sprintf('%.10F', (float) $val), '0'), '.');
                } else {
                    $row[$c - 1] = trim((string) $val);
                }
            }
            $grid[] = $row;
        }
        return $grid;
    }

    private function writeStage(string $token, array $validRecords): void
    {
        if (! is_dir(self::STAGE_DIR)) {
            mkdir(self::STAGE_DIR, 0755, true);
        }
        file_put_contents(self::STAGE_DIR . $token . '.json', json_encode($validRecords));
    }

    private function readStage(string $token): ?array
    {
        $path = self::STAGE_DIR . $token . '.json';
        if (! is_file($path)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($path), true);
        return is_array($data) ? $data : null;
    }

    private function deleteStage(string $token): void
    {
        $path = self::STAGE_DIR . $token . '.json';
        if (is_file($path)) {
            unlink($path);
        }
    }

    private function gcStaleStageFiles(): void
    {
        if (! is_dir(self::STAGE_DIR)) {
            return;
        }
        foreach (glob(self::STAGE_DIR . '*.json') ?: [] as $path) {
            if (time() - filemtime($path) > self::STAGE_TTL) {
                @unlink($path);
            }
        }
    }

    private function denyNonAdmin()
    {
        if (session()->get('role') === 'Admin') {
            return null;
        }
        return $this->response->setStatusCode(403)->setJSON([
            'success' => false,
            'message' => 'Hanya Admin yang dapat mengimpor data.',
        ]);
    }

    private function badRequest(string $message)
    {
        return $this->response->setStatusCode(422)->setJSON([
            'success' => false,
            'message' => $message,
        ]);
    }
}