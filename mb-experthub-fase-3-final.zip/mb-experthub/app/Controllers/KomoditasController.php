<?php

namespace App\Controllers;

use App\Models\KomoditasModel;

/**
 * Sementara hanya endpoint tambah cepat (dipakai tombol "+ Komoditas baru"
 * di form perusahaan). Halaman Master Komoditas (daftar, ganti nama, hapus)
 * menyusul di langkah berikutnya.
 */
class KomoditasController extends BaseController
{
    public function store()
    {
        if (session()->get('role') !== 'Admin') {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Hanya Admin yang dapat menambah komoditas.',
            ]);
        }

        $model = new KomoditasModel();
        $name  = KomoditasModel::normalize($this->request->getPost('name'));
        $id    = $model->insert(['name' => $name]);

        if (! $id) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => 'Validasi gagal.',
                'errors'  => $model->errors(),
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Komoditas ditambahkan',
            'data'    => ['id' => (int) $id, 'name' => $name],
        ]);
    }
}