<?php

namespace App\Controllers;

use App\Libraries\Wilayah;
use App\Models\CompanyModel;
use App\Models\KomoditasModel;

class CompanyController extends BaseController
{
    protected CompanyModel $companyModel;

    // Field kolom biasa dari form. Komoditas (banyak) lewat 'komoditas_ids[]'
    // dan disimpan ke pivot company_komoditas, bukan ke tabel companies.
    private const FIELDS = [
        'name', 'alamat', 'kota', 'provinsi',
        'kontak', 'telepon', 'email',
        'kontak2', 'telepon2', 'email2',
        'status', 'catatan',
    ];

    public function __construct()
    {
        $this->companyModel = new CompanyModel();
    }

    // Render halaman shell — data tabel diambil View lewat fetch() ke data().
    public function index()
    {
        $komoditas = array_map(
            fn ($r) => ['id' => (int) $r['id'], 'name' => $r['name']],
            (new KomoditasModel())->orderBy('name', 'ASC')->findAll()
        );

        return view('companies/index', [
            'crumb'           => 'Master Perusahaan',
            'statusOptions'   => CompanyModel::STATUS_OPTIONS,
            'provinceOptions' => Wilayah::provinces(),
            'wilayah'         => Wilayah::all(),
            'komoditas'       => $komoditas,
            'isAdmin'         => session()->get('role') === 'Admin',
        ]);
    }

    // Endpoint JSON — tiap perusahaan membawa 'komoditas' = [{id, name}, ...].
    public function data()
    {
        $companies = $this->companyModel->orderBy('name', 'ASC')->findAll();
        $byCompany = $this->komoditasByCompany();

        foreach ($companies as &$c) {
            $c['komoditas'] = $byCompany[(int) $c['id']] ?? [];
        }
        unset($c);

        return $this->response->setJSON(['data' => $companies]);
    }

    public function store()
    {
        if ($denied = $this->denyNonAdmin('menambah')) {
            return $denied;
        }

        $data = $this->normalizeWilayah($this->collect());
        $ids  = $this->readKomoditasIds();

        if ($errors = $this->validateInput($data, $ids)) {
            return $this->invalid($errors);
        }

        // Insert perusahaan + kode (hook afterInsert) + pivot komoditas = satu paket.
        $db = \Config\Database::connect();
        $db->transStart();
        $newId = $this->companyModel->insert($data);
        if ($newId) {
            $this->syncKomoditas((int) $newId, $ids);
        }
        $db->transComplete();

        if (! $newId) {
            return $this->invalid($this->companyModel->errors());
        }
        if ($db->transStatus() === false) {
            return $this->serverError();
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Perusahaan baru ditambahkan',
        ]);
    }

    public function update($id)
    {
        if ($denied = $this->denyNonAdmin('mengubah')) {
            return $denied;
        }

        $id       = (int) $id;
        $existing = $this->companyModel->find($id);
        if ($existing === null) {
            return $this->notFound();
        }

        $data = $this->normalizeWilayah($this->collect());
        $ids  = $this->readKomoditasIds();

        // find() bisa array atau objek tergantung $returnType model
        $old = (array) $existing;
        // Kota lama yang di luar daftar hanya dimaafkan bila provinsi tidak berubah
        $keepKota = (($old['provinsi'] ?? null) === $data['provinsi']) ? ($old['kota'] ?? null) : null;

        if ($errors = $this->validateInput($data, $ids, $keepKota)) {
            return $this->invalid($errors);
        }

        // Kode TIDAK ikut diubah: tidak ada di $data, dan tidak ada hook update.
        $db = \Config\Database::connect();
        $db->transStart();
        $ok = $this->companyModel->update($id, $data);
        if ($ok) {
            $this->syncKomoditas($id, $ids);
        }
        $db->transComplete();

        if (! $ok) {
            return $this->invalid($this->companyModel->errors());
        }
        if ($db->transStatus() === false) {
            return $this->serverError();
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Data perusahaan diperbarui',
        ]);
    }

    public function delete($id)
    {
        if ($denied = $this->denyNonAdmin('menghapus')) {
            return $denied;
        }

        if ($this->companyModel->find($id) === null) {
            return $this->notFound();
        }

        // Baris pivot ikut terhapus (FK ON DELETE CASCADE) dan
        // projects.company_id jadi NULL (ON DELETE SET NULL) — keduanya oleh MySQL.
        $this->companyModel->delete($id);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Perusahaan dihapus',
        ]);
    }

    /* ------------------------------------------------------------------ */
    /*  Helper                                                            */
    /* ------------------------------------------------------------------ */

    /** Ambil field kolom biasa dari POST (string di-trim). */
    private function collect(): array
    {
        $data = [];
        foreach (self::FIELDS as $f) {
            $v        = $this->request->getPost($f);
            $data[$f] = is_string($v) ? trim($v) : $v;
        }
        return $data;
    }

    /**
     * Samakan provinsi & kota ke bentuk kanonik Wilayah (HURUF BESAR) sebelum
     * divalidasi/disimpan, jadi 'Jawa Barat', 'jawa barat', dan 'JAWA BARAT'
     * tersimpan sama. Nilai yang tidak dikenal dibiarkan apa adanya agar
     * ditolak oleh validasi.
     */
    private function normalizeWilayah(array $data): array
    {
        $prov = Wilayah::canonicalProvinsi($data['provinsi']);
        if ($prov !== null) {
            $data['provinsi'] = $prov;
            $kota = Wilayah::canonicalKota($prov, $data['kota']);
            if ($kota !== null) {
                $data['kota'] = $kota;
            }
        }
        return $data;
    }

    /** komoditas_ids[] dari POST -> daftar id unik (angka positif). */
    private function readKomoditasIds(): array
    {
        $raw = $this->request->getPost('komoditas_ids');
        $ids = [];
        foreach (is_array($raw) ? $raw : [] as $v) {
            if (ctype_digit((string) $v) && (int) $v > 0) {
                $ids[(int) $v] = (int) $v;
            }
        }
        return array_values($ids);
    }

    /**
     * Semua kesalahan sekaligus (aturan model + provinsi + kota + komoditas),
     * supaya form bisa menandai semua field bermasalah dalam satu kali kirim.
     *
     * @return array<string, string> field => pesan
     */
    private function validateInput(array $data, array $komoditasIds, ?string $keepKota = null): array
    {
        $errors = [];

        if (! $this->companyModel->validate($data)) {
            $errors = $this->companyModel->errors();
        }
        if ($err = $this->provinsiError($data['provinsi'])) {
            $errors['provinsi'] = $err;
        }
        if ($err = $this->kotaError($data['provinsi'], $data['kota'], $keepKota)) {
            $errors['kota'] = $err;
        }
        if ($err = $this->komoditasError($komoditasIds)) {
            $errors['komoditas'] = $err;
        }

        return $errors;
    }

    // Provinsi tak dikenal (mis. request langsung tanpa lewat <select>) ditolak.
    // Sumbernya Wilayah (bukan CompanyModel::PROVINCE_CODES) supaya dropdown,
    // daftar kota, dan validasi selalu memakai satu daftar yang sama.
    private function provinsiError(?string $provinsi): ?string
    {
        return Wilayah::canonicalProvinsi($provinsi) !== null
            ? null
            : 'Provinsi tidak valid.';
    }

    // Kota (opsional) harus termasuk provinsi yang dipilih. Nilai lama yang
    // tidak ada di daftar tetap boleh selama tidak diubah ($existingKota).
    private function kotaError(?string $provinsi, ?string $kota, ?string $existingKota = null): ?string
    {
        $kota = trim((string) $kota);
        if ($kota === '') {
            return null;
        }
        if ($existingKota !== null && $kota === $existingKota) {
            return null;
        }
        return Wilayah::isValid($provinsi, $kota)
            ? null
            : 'Kabupaten/kota tidak sesuai dengan provinsi yang dipilih.';
    }

    // Minimal satu komoditas, dan semua id harus ada di master.
    private function komoditasError(array $ids): ?string
    {
        if ($ids === []) {
            return 'Pilih minimal satu komoditas.';
        }
        $found = (new KomoditasModel())->whereIn('id', $ids)->countAllResults();

        return $found === count($ids) ? null : 'Ada komoditas yang tidak valid.';
    }

    /** Ganti seluruh komoditas perusahaan (hapus lama, tulis baru). Panggil di dalam transaction. */
    private function syncKomoditas(int $companyId, array $ids): void
    {
        $db = \Config\Database::connect();
        $db->table('company_komoditas')->where('company_id', $companyId)->delete();

        $rows = array_map(
            static fn (int $kid) => ['company_id' => $companyId, 'komoditas_id' => $kid],
            $ids
        );
        if ($rows !== []) {
            $db->table('company_komoditas')->insertBatch($rows);
        }
    }

    /** @return array<int, array<int, array{id:int,name:string}>> company_id => daftar komoditas */
    private function komoditasByCompany(): array
    {
        $rows = \Config\Database::connect()
            ->table('company_komoditas ck')
            ->select('ck.company_id, k.id, k.name')
            ->join('komoditas k', 'k.id = ck.komoditas_id')
            ->orderBy('k.name', 'ASC')
            ->get()->getResultArray();

        $out = [];
        foreach ($rows as $r) {
            $out[(int) $r['company_id']][] = ['id' => (int) $r['id'], 'name' => $r['name']];
        }
        return $out;
    }

    private function denyNonAdmin(string $aksi)
    {
        if (session()->get('role') === 'Admin') {
            return null;
        }
        return $this->response->setStatusCode(403)->setJSON([
            'success' => false,
            'message' => "Hanya Admin yang dapat {$aksi} data.",
        ]);
    }

    private function invalid(array $errors)
    {
        return $this->response->setStatusCode(422)->setJSON([
            'success' => false,
            'message' => 'Validasi gagal.',
            'errors'  => $errors,
        ]);
    }

    private function notFound()
    {
        return $this->response->setStatusCode(404)->setJSON([
            'success' => false,
            'message' => 'Data tidak ditemukan.',
        ]);
    }

    private function serverError()
    {
        return $this->response->setStatusCode(500)->setJSON([
            'success' => false,
            'message' => 'Gagal menyimpan data. Coba lagi.',
        ]);
    }
}