<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class RoleFilter implements FilterInterface
{
    // Mapping ini pengganti ROLE_ACCESS di JS lama
    protected array $roleAccess = [
        'Admin' => ['dashboard', 'talent', 'repo', 'project', 'documents', 'knowledge', 'map', 'analytics', 'users', 'settings'],
        'Umum'  => ['dashboard', 'talent', 'repo', 'project', 'knowledge', 'map', 'analytics', 'settings'],
    ];

    public function before(RequestInterface $request, $arguments = null)
    {
        // 1. Belum login sama sekali? Tendang ke halaman login.
        if (! session()->get('isLoggedIn')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        // 2. Filter dipasang tanpa argumen -> cukup cek sudah login, tidak cek role spesifik.
        if (empty($arguments)) {
            return;
        }

        // 3. $arguments datang dari Routes.php, contoh: ['documents']
        $requiredRoute = $arguments[0];
        $userRole      = session()->get('role');

        $allowed = $this->roleAccess[$userRole] ?? [];

        if (! in_array($requiredRoute, $allowed, true)) {
            return redirect()->to('/dashboard')->with('error', 'Fitur ini hanya tersedia untuk Admin.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak perlu apa-apa di sini untuk sekarang.
    }
}