<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $users = [
            [
                'kode'     => 'U-A001',
                'name'     => 'Administrator',
                'email'    => 'admin@sucofindo.co.id',
                'password' => password_hash('admin123', PASSWORD_DEFAULT),
                'role'     => 'Admin',
                'branch'   => 'Pusat',
                'status'   => 'Aktif',
            ],
            [
                'kode'     => 'U-A002',
                'name'     => 'Daffa MT KSP',
                'email'    => 'daffa@sucofindo.co.id',
                'password' => password_hash('daffa123', PASSWORD_DEFAULT),
                'role'     => 'Admin',
                'branch'   => 'SBU KSP',
                'status'   => 'Aktif',
            ],
            [
                'kode'     => 'U-U001',
                'name'     => 'Andri Wibowo',
                'email'    => 'umum@sucofindo.co.id',
                'password' => password_hash('umum123', PASSWORD_DEFAULT),
                'role'     => 'Umum',
                'branch'   => 'Jakarta',
                'status'   => 'Aktif',
            ],
            [
                'kode'     => 'U-U004',
                'name'     => 'Internal Auditor',
                'email'    => 'auditor@sucofindo.co.id',
                'password' => password_hash('audit123', PASSWORD_DEFAULT),
                'role'     => 'Umum',
                'branch'   => 'Pusat',
                'status'   => 'Nonaktif', // sengaja, buat tes akun nonaktif ditolak login
            ],
        ];

        foreach ($users as $user) {
            $this->db->table('users')->insert($user);
        }
    }
}