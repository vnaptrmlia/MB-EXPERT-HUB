<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Pivot perusahaan <-> komoditas (many-to-many).
 *  - hapus perusahaan  -> barisnya ikut terhapus (CASCADE)
 *  - hapus komoditas yang masih dipakai -> DITOLAK database (RESTRICT)
 *
 * Tipe kolom company_id dibaca dari companies.id supaya foreign key pasti
 * cocok (INT/BIGINT, signed/unsigned) tanpa menebak isi migration lama.
 */
class CreateCompanyKomoditasTable extends Migration
{
    public function up()
    {
        $type = $this->companyIdType();

        $this->db->query("
            CREATE TABLE company_komoditas (
                company_id   {$type} NOT NULL,
                komoditas_id INT UNSIGNED NOT NULL,
                PRIMARY KEY (company_id, komoditas_id),
                KEY idx_ck_komoditas (komoditas_id),
                CONSTRAINT fk_ck_company   FOREIGN KEY (company_id)   REFERENCES companies (id) ON DELETE CASCADE,
                CONSTRAINT fk_ck_komoditas FOREIGN KEY (komoditas_id) REFERENCES komoditas (id) ON DELETE RESTRICT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        // ---- pindahkan data lama: companies.komoditas -> pivot ----
        $map = [];
        foreach ($this->db->table('komoditas')->get()->getResultArray() as $k) {
            $map[mb_strtolower($k['name'])] = (int) $k['id'];
        }

        $rows = [];
        foreach ($this->db->table('companies')->select('id, komoditas')->get()->getResultArray() as $c) {
            foreach ($this->split($c['komoditas'] ?? '') as $name) {
                $kid = $map[mb_strtolower($name)] ?? null;
                if ($kid !== null) {
                    $rows[$c['id'] . '-' . $kid] = ['company_id' => $c['id'], 'komoditas_id' => $kid];
                }
            }
        }
        foreach (array_chunk(array_values($rows), 500) as $chunk) {
            $this->db->table('company_komoditas')->ignore(true)->insertBatch($chunk);
        }
    }

    public function down()
    {
        $this->forge->dropTable('company_komoditas', true);
    }

    private function companyIdType(): string
    {
        $col  = $this->db->query("SHOW COLUMNS FROM companies LIKE 'id'")->getRowArray();
        $type = strtolower($col['Type'] ?? '');

        if (! preg_match('/^(tiny|small|medium|big)?int(\(\d+\))?( unsigned)?$/', $type)) {
            throw new \RuntimeException("Tipe companies.id tidak dikenali: '{$type}'");
        }
        return $type;
    }

    /** @return string[] */
    private function split(?string $value): array
    {
        $out = [];
        foreach (preg_split('/[,;\r\n]+/', (string) $value) as $part) {
            $part = trim(preg_replace('/\s+/u', ' ', $part));
            if ($part !== '') {
                $out[] = $part;
            }
        }
        return $out;
    }
}