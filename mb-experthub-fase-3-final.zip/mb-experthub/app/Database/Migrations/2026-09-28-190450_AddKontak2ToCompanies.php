<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Kontak kedua per perusahaan. Kolom lama kontak / telepon / email tetap
 * sebagai kontak 1 (tidak diganti nama, tidak ada data yang dipindah).
 * Ketiga kolom baru boleh kosong satu per satu: di data Excel kontak 2
 * sering hanya berisi e-mail atau telepon.
 */
class AddKontak2ToCompanies extends Migration
{
    public function up()
    {
        $this->forge->addColumn('companies', [
            'kontak2'  => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true, 'after' => 'email'],
            'telepon2' => ['type' => 'VARCHAR', 'constraint' => 50,  'null' => true, 'after' => 'kontak2'],
            'email2'   => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true, 'after' => 'telepon2'],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('companies', ['kontak2', 'telepon2', 'email2']);
    }
}