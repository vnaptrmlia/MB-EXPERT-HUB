<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\I18n\Time;

/**
 * Master komoditas. Diisi otomatis dari nilai companies.komoditas yang sudah ada
 * (dipecah pada koma / titik koma / baris baru, duplikat dibuang tanpa peduli
 * huruf besar-kecil). Kolom companies.komoditas TIDAK diubah di migration ini.
 */
class CreateKomoditasTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'name'       => ['type' => 'VARCHAR', 'constraint' => 255],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('name'); // collation *_ci -> unik tanpa peduli huruf besar/kecil
        $this->forge->createTable('komoditas');

        // ---- isi awal dari data perusahaan yang ada ----
        $seen = [];
        foreach ($this->db->table('companies')->select('komoditas')->get()->getResultArray() as $row) {
            foreach ($this->split($row['komoditas'] ?? '') as $name) {
                $seen[mb_strtolower($name)] ??= $name;
            }
        }

        if ($seen) {
            $now  = Time::now()->toDateTimeString();
            $rows = [];
            foreach ($seen as $name) {
                $rows[] = ['name' => $name, 'created_at' => $now, 'updated_at' => $now];
            }
            $this->db->table('komoditas')->insertBatch($rows);
        }
    }

    public function down()
    {
        $this->forge->dropTable('komoditas', true);
    }

    /** @return string[] */
    private function split(?string $value): array
    {
        $out = [];
        foreach (preg_split('/[,;\r\n]+/', (string) $value) as $part) {
            $part = trim(preg_replace('/\s+/u', ' ', $part));
            if ($part !== '') {
                $out[] = $part;
            }
        }
        return $out;
    }
}