<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateProjectTalentsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'project_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'talent_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('project_id', 'projects', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('talent_id', 'talents', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('project_talents');
    }

    public function down()
    {
        $this->forge->dropTable('project_talents');
    }
}