<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddCompanyIdToProjectsTable extends Migration
{
    public function up()
    {
        $this->forge->addColumn('projects', [
            'company_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
                'after'      => 'client',
            ],
        ]);

        $this->forge->addForeignKey('company_id', 'companies', 'id', 'SET NULL', 'CASCADE', 'projects');
    }

    public function down()
    {
        $this->forge->dropForeignKey('projects', 'projects_company_id_foreign');
        $this->forge->dropColumn('projects', 'company_id');
    }
}