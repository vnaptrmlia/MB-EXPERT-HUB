<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Kode perusahaan kini diturunkan dari id (CMP-0001), bukan dari provinsi.
 *  - kolom `kode` harus boleh NULL sebentar: baris di-insert dulu, id baru
 *    diketahui setelahnya, lalu kode diisi (dalam satu transaction).
 *  - `kode` dijamin unik oleh database.
 */
class MakeCompanyKodeUnique extends Migration
{
    public function up()
    {
        $this->forge->modifyColumn('companies', [
            'kode' => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
        ]);

        // Tambah UNIQUE hanya kalau belum ada (migration lama mungkin sudah membuatnya)
        $hasUnique = $this->db->query(
            "SHOW INDEX FROM companies WHERE Column_name = 'kode' AND Non_unique = 0"
        )->getNumRows() > 0;

        if (! $hasUnique) {
            $this->db->query('ALTER TABLE companies ADD UNIQUE KEY uq_companies_kode (kode)');
        }
    }

    public function down()
    {
        // Sengaja tidak mengembalikan NOT NULL: baris bisa saja sudah bernilai NULL.
        $this->db->query('ALTER TABLE companies DROP INDEX uq_companies_kode');
    }
}
