<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - MB-ExpertHub</title>
  <link rel="stylesheet" href="<?= base_url('assets/css/app.css') ?>">
</head>
<body>

<div id="login-screen">
  <div class="login-shapes"><span></span><span></span><span></span></div>

  <div class="login-card">
    <div class="login-logo">
      <div class="login-logo-mark">MB</div>
      <div>
        <div class="login-brand">SUCOFINDO</div>
        <div style="font-size:10px;color:var(--c-text-mute);letter-spacing:1px">MB-EXPERTHUB</div>
      </div>
    </div>

    <h1>Selamat datang kembali</h1>
    <div class="sub">Talent Pooling &amp; Knowledge Repository<br/>for Material Balance Verification</div>

    <?php if (session()->getFlashdata('error')): ?>
      <div class="login-banner show">
        <div><?= esc(session()->getFlashdata('error')) ?></div>
      </div>
    <?php endif; ?>

    <form action="<?= site_url('login') ?>" method="post">
      <?= csrf_field() ?>

      <div class="field">
        <label for="email">Email</label>
        <input type="email" id="email" name="email"
               value="<?= esc(old('email')) ?>" placeholder="nama@sucofindo.co.id" required autofocus>
      </div>

      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="••••••••" required>
      </div>

      <button type="submit" class="btn-login">Masuk ke MB-ExpertHub</button>
    </form>
  </div>
</div>

</body>
</html>