<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="hero">
  <div class="hero-content">
    <div class="hero-eyebrow">MB-EXPERTHUB · SUCOFINDO</div>
    <h1>Selamat datang, <span><?= esc(session()->get('name')) ?></span>.<br/>
        Siap mempercepat <span>Verifikasi Material Balance</span> hari ini?</h1>
    <p>Talent pooling, repository teknis, dan histori project terintegrasi dalam satu platform.</p>
    <div class="hero-meta">
      <div><b>—</b>Tenaga Ahli</div>
      <div><b>—</b>Referensi Teknis</div>
      <div><b>—</b>Project Tercatat</div>
    </div>
  </div>
</div>

<div class="stat-grid">
  <div class="stat s-blue"><div class="ico">🏢</div><div class="label">Total Perusahaan</div><div class="val">—</div></div>
  <div class="stat s-orange"><div class="ico">⏳</div><div class="label">Project Ongoing</div><div class="val">—</div></div>
  <div class="stat s-green"><div class="ico">✅</div><div class="label">Project Completed</div><div class="val">—</div></div>
  <div class="stat s-purple"><div class="ico">📍</div><div class="label">Total Cabang</div><div class="val">—</div></div>
</div>

<?= $this->endSection() ?>