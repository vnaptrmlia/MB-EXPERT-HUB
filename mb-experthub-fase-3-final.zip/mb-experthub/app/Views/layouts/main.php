<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $title ?? 'MB-ExpertHub' ?></title>
  <link rel="stylesheet" href="<?= base_url('assets/css/app.css') ?>">
</head>
<body data-role="<?= esc(session()->get('role')) ?>">
  <div id="app" style="display:block">
    <div class="app-grid">

      <!-- SIDEBAR -->
      <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
          <div class="mark">MB</div>
          <div>
            <div class="name">MB-ExpertHub</div>
            <div class="sub">Sucofindo</div>
          </div>
        </div>
        <nav class="nav-section">
          <div class="nav-label">Menu</div>
          <a href="<?= base_url('dashboard') ?>"
             class="nav-item <?= uri_string() === 'dashboard' ? 'active' : '' ?>">
            <span class="ico">🏠</span> Dashboard
          </a>
          <a href="<?= base_url('perusahaan') ?>"
             class="nav-item <?= strpos(uri_string(), 'perusahaan') === 0 ? 'active' : '' ?>">
            <span class="ico">🏢</span> Master Perusahaan
          </a>
          <!-- Modul lain (Talent, Repo, Project, dst) ditambahin satu-satu
               di sini begitu tiap modul selesai dibikin di Fase 3
               berikutnya. Sengaja belum dicantumin sekarang biar nggak ada
               link nunjuk ke halaman yang belum ada (dead link / 404). -->
        </nav>
        <div class="sidebar-foot">
          Build 1.0 · CI4<br/>SBU KSP — Sucofindo
        </div>
      </aside>

      <!-- MAIN -->
      <div class="main">
        <header class="topbar">
          <div class="breadcrumb">MB-ExpertHub / <b><?= esc($crumb ?? 'Dashboard') ?></b></div>
          <div class="topbar-actions" style="margin-left:auto;display:flex;align-items:center;gap:12px">
            <div class="user-chip">
              <div class="avatar"><?= esc(strtoupper(substr(session()->get('name') ?? '?', 0, 1))) ?></div>
              <div>
                <div class="name"><?= esc(session()->get('name')) ?></div>
                <div class="role"><?= session()->get('role') === 'Admin' ? 'Administrator' : 'User Umum' ?></div>
              </div>
            </div>
            <a href="<?= base_url('logout') ?>" class="icon-btn" title="Logout">↩</a>
          </div>
        </header>

        <main class="content">
          <?= $this->renderSection('content') ?>
        </main>
      </div>
    </div>
  </div>
</body>
</html>