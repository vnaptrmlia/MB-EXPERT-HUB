<?php

namespace App\Models;

use CodeIgniter\Model;

class KomoditasModel extends Model
{
    protected $table            = 'komoditas';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['name'];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Koma dan titik koma adalah PEMISAH komoditas di sel Excel, jadi tidak
    // boleh ada di dalam satu nama. {id} diisi otomatis saat update supaya
    // nama sendiri tidak dianggap duplikat.
    protected $validationRules = [
        'name' => 'required|max_length[255]|regex_match[/^[^,;]+$/]|is_unique[komoditas.name,id,{id}]',
    ];

    protected $validationMessages = [
        'name' => [
            'required'    => 'Nama komoditas wajib diisi.',
            'max_length'  => 'Nama komoditas maksimal 255 karakter.',
            'regex_match' => 'Nama komoditas tidak boleh mengandung koma atau titik koma.',
            'is_unique'   => 'Komoditas ini sudah ada.',
        ],
    ];

    /** Rapikan spasi: trim + spasi ganda jadi satu. */
    public static function normalize(?string $name): string
    {
        return trim((string) preg_replace('/\s+/u', ' ', (string) $name));
    }

    /**
     * Pecah satu sel menjadi daftar nama komoditas (dipisah koma, titik koma,
     * atau baris baru). Kata "dan"/"atau" TIDAK memisahkan. Duplikat dibuang
     * tanpa peduli huruf besar-kecil; urutan kemunculan dipertahankan.
     *
     * @return string[]
     */
    public static function splitNames(?string $cell): array
    {
        $out = [];
        foreach (preg_split('/[,;\r\n]+/', (string) $cell) as $part) {
            $name = self::normalize($part);
            if ($name !== '') {
                $out[mb_strtolower($name)] ??= $name;
            }
        }
        return array_values($out);
    }
}