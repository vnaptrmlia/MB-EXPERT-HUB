<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;

    protected $allowedFields = [
        'kode', 'name', 'email', 'password', 'role',
        'branch', 'status', 'last_login',
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'name'     => 'required|min_length[3]|max_length[150]',
        'email'    => 'required|valid_email',
        'role'     => 'required|in_list[Admin,Umum]',
    ];

    protected $validationMessages = [
        'email' => [
            'valid_email' => 'Format email tidak valid.',
        ],
    ];
}