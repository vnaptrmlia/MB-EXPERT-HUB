<?php

namespace App\Models;

use CodeIgniter\Model;

class CompanyModel extends Model
{
    protected $table            = 'companies';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    // Komoditas sekarang di tabel pivot company_komoditas (banyak per perusahaan),
    // jadi kolom lama companies.komoditas tidak lagi ditulis.
    // 'id' dan 'kode' sengaja TIDAK ada di sini. 'kode' diisi otomatis oleh
    // hook afterInsert (dari id) dan tidak boleh diubah lewat form/request.
    protected $allowedFields = [
        'name', 'alamat', 'kota', 'provinsi',
        'kontak', 'telepon', 'email',
        'kontak2', 'telepon2', 'email2',
        'status', 'catatan',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime'; // cocok sama kolom DATETIME created_at/updated_at
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Prefix kode perusahaan: CMP-0001, CMP-0002, dst. (diturunkan dari id)
    public const KODE_PREFIX = 'CMP';

    // Pilihan status yang valid — dipakai di validation rule (in_list)
    // DAN di View buat isi <select>, jadi satu sumber kebenaran.
    public const STATUS_OPTIONS = [
        'Belum Dihubungi',
        'Sudah Dihubungi',
        'Follow Up',
        'Tertarik',
        'Tidak Tertarik',
    ];

    // Daftar provinsi yang valid (kunci array) — dipakai buat isi <select>
    // provinsi di form dan buat validasi di Controller. Kunci HARUS sama
    // persis dengan kunci App\Libraries\Wilayah::DATA.
    //
    // Nilai 3 huruf di sisi kanan peninggalan skema kode lama (JBR-0001).
    // Sekarang sudah TIDAK dipakai untuk apa pun; boleh diubah jadi daftar
    // biasa nanti kalau mau dirapikan.
    public const PROVINCE_CODES = [
        'Aceh' => 'ACE', 'Sumatera Utara' => 'SUT', 'Sumatera Barat' => 'SUB',
        'Riau' => 'RIA', 'Kepulauan Riau' => 'KRI', 'Jambi' => 'JMB',
        'Sumatera Selatan' => 'SUS', 'Kepulauan Bangka Belitung' => 'BBL',
        'Bengkulu' => 'BEN', 'Lampung' => 'LAM', 'DKI Jakarta' => 'DKI',
        'Jawa Barat' => 'JBR', 'Jawa Tengah' => 'JTG', 'DI Yogyakarta' => 'DIY',
        'Jawa Timur' => 'JTM', 'Banten' => 'BAN', 'Bali' => 'BAL',
        'Nusa Tenggara Barat' => 'NTB', 'Nusa Tenggara Timur' => 'NTT',
        'Kalimantan Barat' => 'KBR', 'Kalimantan Tengah' => 'KTG',
        'Kalimantan Selatan' => 'KSL', 'Kalimantan Timur' => 'KTM',
        'Kalimantan Utara' => 'KUT', 'Sulawesi Utara' => 'SUL',
        'Sulawesi Tengah' => 'STG', 'Sulawesi Selatan' => 'SSL',
        'Sulawesi Tenggara' => 'STR', 'Gorontalo' => 'GOR',
        'Sulawesi Barat' => 'SBR', 'Maluku' => 'MAL', 'Maluku Utara' => 'MUT',
        'Papua' => 'PPA', 'Papua Barat' => 'PBR', 'Papua Tengah' => 'PTG',
        'Papua Pegunungan' => 'PPG', 'Papua Selatan' => 'PSL',
        'Papua Barat Daya' => 'PBD',
    ];

    protected $validationRules = [
        'name'      => 'required|max_length[200]',
        'provinsi'  => 'required',
        'status'    => 'permit_empty|in_list[Belum Dihubungi,Sudah Dihubungi,Follow Up,Tertarik,Tidak Tertarik]',
        'email'     => 'permit_empty|valid_email|max_length[150]',
        'telepon'   => 'permit_empty|max_length[30]',
        'kontak2'   => 'permit_empty|max_length[200]',
        'telepon2'  => 'permit_empty|max_length[50]',
        'email2'    => 'permit_empty|valid_email|max_length[150]',
    ];

    protected $validationMessages = [
        'name'      => ['required' => 'Nama perusahaan wajib diisi.'],
        'provinsi'  => ['required' => 'Provinsi wajib dipilih.'],
    ];

    // Kode dibuat SEKALI setelah insert (id baru diketahui setelahnya) dan
    // tidak pernah berubah, jadi tidak ada hook update.
    protected $afterInsert = ['assignKode'];

    /**
     * Isi kolom `kode` dari id: CMP-0001, CMP-0002, ...
     *
     * Lewat builder langsung, BUKAN $this->update(), supaya updated_at tidak
     * ikut berubah dan tidak memicu event update. Pemanggil (Controller)
     * membungkus insert() dengan transaction, jadi kalau langkah ini gagal
     * tidak ada baris yang tersisa tanpa kode.
     */
    protected function assignKode(array $data): array
    {
        $id = $data['id'] ?? null;

        if ($id) {
            $this->builder()
                 ->where($this->primaryKey, $id)
                 ->update(['kode' => sprintf('%s-%04d', self::KODE_PREFIX, $id)]);
        }

        return $data;
    }
}