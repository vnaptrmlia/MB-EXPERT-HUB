(function () {
  const cfg = window.KOMODITAS_CFG;
  let rows = [];        // dari server: [{id, name, usage_count}]
  let editingId = null; // null = mode tambah
  let deletingId = null;
  let saving = false;

  const $ = (id) => document.getElementById(id);

  // Escape HTML: WAJIB tiap nyisipin data user ke innerHTML.
  function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function toast(title, msg, type = 'success') {
    const icons = { success: '✓', error: '✕', warning: '!' };
    const div = document.createElement('div');
    div.className = 'toast t-' + type;
    div.innerHTML =
      `<div class="icon">${icons[type] || 'ℹ'}</div>` +
      `<div class="body"><div class="title">${esc(title)}</div><div class="msg">${esc(msg)}</div></div>`;
    let host = $('toast-host');
    if (!host) {
      host = document.createElement('div');
      host.id = 'toast-host';
      host.className = 'toast-host';
      document.body.appendChild(host);
    }
    host.appendChild(div);
    setTimeout(() => div.remove(), 3200);
  }

  const openModal  = (id) => $(id).classList.add('open');
  const closeModal = (id) => $(id).classList.remove('open');

  /* ---------- CSRF ----------
     regenerate = true -> token berubah setelah SETIAP POST yang lolos.
     Token terbaru dikirim server lewat header respons (lihat BaseController)
     dan disimpan di cfg.csrfToken untuk request berikutnya. */
  function syncCsrf(res) {
    const t = res.headers.get(cfg.csrfHeader);
    if (t) cfg.csrfToken = t;
  }

  async function post(url, formData) {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json',
        [cfg.csrfHeader]: cfg.csrfToken,
      },
      body: formData || new FormData(),
    });
    syncCsrf(res);
    let json = null;
    try { json = await res.json(); } catch (_) { /* respons bukan JSON */ }
    return { status: res.status, json };
  }

  /* ---------- Ambil & render data ---------- */
  async function loadData() {
    try {
      const res = await fetch(cfg.urls.data, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      syncCsrf(res);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      rows = json.data || [];
      render();
    } catch (e) {
      console.error(e);
      $('tbody-komoditas').innerHTML =
        '<tr><td colspan="3">Gagal memuat data. Muat ulang halaman.</td></tr>';
    }
  }

  function render() {
    const q = $('search-komoditas').value.trim().toLowerCase();
    const list = q ? rows.filter((r) => r.name.toLowerCase().includes(q)) : rows;

    const tb = $('tbody-komoditas');
    if (list.length === 0) {
      tb.innerHTML = '<tr><td colspan="3">' +
        (rows.length ? 'Tidak ada komoditas yang cocok dengan pencarian.' : 'Belum ada komoditas.') +
        '</td></tr>';
      return;
    }

    tb.innerHTML = list.map((r) => `
      <tr>
        <td data-th="Nama">${esc(r.name)}</td>
        <td data-th="Dipakai" style="text-align:right">
          <span class="usage-count${r.usage_count === 0 ? ' zero' : ''}">${r.usage_count} perusahaan</span>
        </td>
        <td data-th="Aksi"><div class="row-actions">
          ${cfg.isAdmin ? `
            <button class="icon-btn" data-act="edit" data-id="${r.id}" title="Ganti nama">✎</button>
            <button class="icon-btn" data-act="delete" data-id="${r.id}" title="Hapus">🗑</button>
          ` : ''}
        </div></td>
      </tr>`).join('');
  }

  $('search-komoditas').addEventListener('input', render);

  // Tutup modal: tombol [data-close], klik area gelap, tombol Esc
  document.addEventListener('click', (e) => {
    const closer = e.target.closest('[data-close]');
    if (closer) closeModal(closer.dataset.close);
    if (e.target.classList.contains('modal-backdrop')) e.target.classList.remove('open');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape')
      document.querySelectorAll('.modal-backdrop.open').forEach((m) => m.classList.remove('open'));
  });

  /* ---------- Tambah / Edit ---------- */
  function findById(id) { return rows.find((r) => Number(r.id) === Number(id)); }

  function clearError() {
    const f = $('fk-name').closest('.form-field');
    f.classList.remove('invalid');
    f.querySelector('.err').textContent = '';
  }
  function setError(msg) {
    const f = $('fk-name').closest('.form-field');
    f.classList.add('invalid');
    f.querySelector('.err').textContent = msg;
  }

  function openForm(id) {
    if (!cfg.isAdmin) { toast('Akses ditolak', 'Hanya Admin yang dapat mengubah data.', 'error'); return; }
    const r = id ? findById(id) : null;
    if (id && !r) { toast('Gagal', 'Data tidak ditemukan. Muat ulang halaman.', 'error'); return; }

    editingId = r ? r.id : null;
    clearError();
    $('form-title').textContent = r ? 'Ganti Nama Komoditas' : 'Tambah Komoditas';
    $('fk-name').value = r ? r.name : '';
    openModal('modal-form');
    $('fk-name').focus();
  }

  async function saveForm(ev) {
    ev.preventDefault();
    if (saving) return;
    clearError();

    const name = $('fk-name').value.trim();
    if (!name) { setError('Nama komoditas wajib diisi'); return; }
    if (name.includes(',') || name.includes(';')) {
      setError('Nama komoditas tidak boleh mengandung koma atau titik koma');
      return;
    }

    const fd = new FormData();
    fd.append('name', name);

    const btn = $('btn-form-save');
    const oldLabel = btn.textContent;
    saving = true; btn.disabled = true; btn.textContent = 'Menyimpan...';

    try {
      const url = editingId ? cfg.urls.update + editingId : cfg.urls.store;
      const { status, json } = await post(url, fd);

      if (status === 200 && json && json.success) {
        closeModal('modal-form');
        toast('Berhasil', json.message || 'Tersimpan');
        await loadData();
      } else if (status === 422 && json) {
        const msgs = Object.values((json.errors || {}));
        setError(msgs[0] || json.message || 'Data tidak valid.');
      } else if (status === 403 && json && json.message) {
        toast('Akses ditolak', json.message, 'error');
      } else if (status === 404) {
        closeModal('modal-form');
        toast('Gagal', 'Data sudah tidak ada.', 'error');
        await loadData();
      } else {
        toast('Gagal menyimpan',
          'Server menolak permintaan (HTTP ' + status + '). Muat ulang halaman lalu coba lagi.', 'error');
      }
    } catch (e) {
      console.error(e);
      toast('Gagal menyimpan', 'Tidak bisa menghubungi server.', 'error');
    } finally {
      saving = false; btn.disabled = false; btn.textContent = oldLabel;
    }
  }

  /* ---------- Hapus ---------- */
  function askDelete(id) {
    const r = findById(id);
    if (!r) return;
    deletingId = r.id;
    if (r.usage_count > 0) {
      $('confirm-msg').innerHTML =
        `"${esc(r.name)}" masih dipakai <b>${r.usage_count} perusahaan</b> dan tidak bisa dihapus. ` +
        `Lepaskan komoditas ini dari perusahaan yang memakainya dulu.`;
      $('btn-confirm-ok').style.display = 'none';
    } else {
      $('confirm-msg').textContent = `"${r.name}" akan dihapus. Tindakan ini tidak bisa dibatalkan.`;
      $('btn-confirm-ok').style.display = '';
    }
    openModal('modal-confirm');
  }

  async function confirmDelete() {
    if (deletingId === null || saving) return;
    const id = deletingId;
    const btn = $('btn-confirm-ok');
    saving = true; btn.disabled = true;
    try {
      const { status, json } = await post(cfg.urls.remove + id);
      closeModal('modal-confirm');
      if (status === 200 && json && json.success) {
        toast('Berhasil', json.message || 'Komoditas dihapus');
      } else if (status === 422 && json && json.message) {
        toast('Tidak bisa dihapus', json.message, 'error');
      } else if (status === 404) {
        toast('Info', 'Data sudah tidak ada.', 'warning');
      } else if (status === 403 && json && json.message) {
        toast('Akses ditolak', json.message, 'error');
      } else {
        toast('Gagal menghapus',
          'Server menolak permintaan (HTTP ' + status + '). Muat ulang halaman lalu coba lagi.', 'error');
      }
      await loadData();
    } catch (e) {
      console.error(e);
      closeModal('modal-confirm');
      toast('Gagal menghapus', 'Tidak bisa menghubungi server.', 'error');
    } finally {
      saving = false; btn.disabled = false; deletingId = null;
    }
  }

  /* ---------- Event binding ---------- */
  $('tbody-komoditas').addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const id = btn.dataset.id;
    if (btn.dataset.act === 'edit') openForm(id);
    else if (btn.dataset.act === 'delete') askDelete(id);
  });

  const addBtn = $('btn-add-komoditas'); // hanya dirender untuk Admin
  if (addBtn) addBtn.addEventListener('click', () => openForm(null));

  $('komoditas-form').addEventListener('submit', saveForm);
  $('btn-confirm-ok').addEventListener('click', confirmDelete);

  loadData();
})();