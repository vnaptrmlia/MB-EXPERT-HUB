<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<style>
  .chips{display:flex;flex-wrap:wrap;gap:6px;min-height:36px;padding:6px;border:1px solid var(--c-border);border-radius:8px;background:var(--c-card)}
  .chip{display:inline-flex;align-items:center;gap:2px;max-width:100%;min-width:0;padding:3px 4px 3px 10px;border-radius:999px;background:var(--c-purple-bg);color:#6d28d9;font-size:12px}
  .chip-text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
  .chip-x{border:0;background:transparent;color:inherit;cursor:pointer;font-size:15px;line-height:1;padding:0 6px;border-radius:50%;flex:0 0 auto}
  .chip-x:hover{background:rgba(109,40,217,.15)}
  .chip-empty{color:var(--c-text-mute);font-size:12px;align-self:center;padding-left:4px}
  .kom-add,.kom-new{display:flex;gap:8px;margin-top:8px;align-items:center}
  .kom-add select,.kom-new input{flex:1;min-width:0}
  .kom-new-err{color:var(--c-danger);font-size:12px;margin-top:4px}
  /* Badge komoditas di tabel & modal detail.
     Kunci bug flexbox: anak flex dengan white-space:nowrap punya min-width
     OTOMATIS = lebar penuh teksnya, dan min-width itu MENGALAHKAN max-width.
     Tanpa min-width:0 di sini, max-width+ellipsis di bawah tidak pernah
     benar-benar berlaku, badge dirender selebar teks aslinya dan melebarkan
     tabel / bocor keluar kolom. */
  .kom-badges{display:flex;flex-wrap:wrap;gap:4px;min-width:0;overflow:hidden}
  .kom-badges .badge{min-width:0;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

  /* Kolom Komoditas di TABEL: kunci lebar kolom supaya nama panjang tidak
     ikut melebarkan tabel; badge di dalamnya yang terpotong, bukan kolomnya. */
  td.td-komoditas{max-width:220px;overflow:hidden}

  /* Modal Detail: ruang lebih lega — tampilkan nama komoditas penuh, boleh
     turun baris, tidak dipotong seperti di tabel. */
  #detail-body .kom-badges{overflow:visible}
  #detail-body .kom-badges .badge{max-width:none;white-space:normal;overflow:visible;text-overflow:clip}
  /* Modal: .modal = flex kolom setinggi maks 90vh (overflow:hidden), .modal-body = area scroll.
     Form membungkus body + footer, jadi form harus ikut jadi flex-kolom; kalau tidak,
     .modal-body tidak pernah dibatasi tingginya dan isi form terpotong tanpa bisa di-scroll. */
  #company-form{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}
  #company-form .modal-body{flex:1 1 auto;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch}
  #company-form .modal-foot{flex:0 0 auto}
  .form-section{font-size:12px;font-weight:700;color:var(--c-text-soft);text-transform:uppercase;letter-spacing:.04em;margin-top:6px}

  .import-drop{border:2px dashed var(--c-border-strong);border-radius:10px;padding:22px;text-align:center;cursor:pointer;background:var(--c-card)}
  .import-drop:hover{border-color:var(--c-purple)}
  .import-drop input{display:none}
  .import-filename{font-size:13px;color:var(--c-text-soft);margin-top:8px}
  .import-summary{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}
  .import-stat{flex:1 1 100px;text-align:center;padding:10px;border-radius:8px;background:var(--c-card);border:1px solid var(--c-border)}
  .import-stat b{display:block;font-size:20px}
  .import-stat.ok b{color:var(--c-success)}
  .import-stat.skip b{color:var(--c-text-mute)}
  .import-stat.bad b{color:var(--c-danger)}
  .import-list{max-height:160px;overflow-y:auto;border:1px solid var(--c-border);border-radius:8px;padding:8px 10px;font-size:12px;margin-bottom:10px}
  .import-list div{padding:3px 0;border-bottom:1px solid var(--c-border);word-break:break-word}
  .import-list div:last-child{border-bottom:0}
  .import-list.warn div{color:var(--c-warning)}
  .import-list.bad div{color:var(--c-danger)}
  .import-list.new div{color:#6d28d9}
  .import-section-title{font-size:12px;font-weight:700;margin:10px 0 4px;color:var(--c-text-soft)}
  .import-hint{font-size:12px;color:var(--c-text-mute);margin-top:4px}

  th[data-sort]{cursor:pointer;user-select:none;white-space:nowrap}
  th[data-sort]:hover{color:var(--c-purple)}
  th[data-sort] .sort-arrow{display:inline-block;width:1em;opacity:.35;font-size:10px}
  th[data-sort].sort-active .sort-arrow{opacity:1;color:var(--c-purple)}
</style>

<div class="page-header">
  <div>
    <h2>Master Perusahaan</h2>
    <div class="desc">Database perusahaan yang dapat dihubungi</div>
  </div>
  <div class="actions">
    <?php if ($isAdmin): ?>
      <a class="btn btn-secondary" href="<?= site_url('perusahaan/import/template') ?>">Unduh Template</a>
      <button class="btn btn-secondary" id="btn-open-import">Import Excel</button>
      <button class="btn btn-primary" id="btn-add-company">+ Tambah Perusahaan</button>
    <?php endif; ?>
  </div>
</div>

<div class="table-wrap">
  <div class="table-tools">
    <div class="input-search">
      <span>🔍</span>
      <input id="search-perusahaan" placeholder="Cari nama, komoditas, kota..."/>
    </div>
    <select class="input" id="filter-komoditas"><option value="">Semua Komoditas</option></select>
    <select class="input" id="filter-status">
      <option value="">Semua Status</option>
      <?php foreach ($statusOptions as $s): ?>
        <option value="<?= esc($s) ?>"><?= esc($s) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="input" id="filter-provinsi">
      <option value="">Semua Provinsi</option>
      <?php foreach ($provinceOptions as $p): ?>
        <option value="<?= esc($p) ?>"><?= esc($p) ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="table-scroll">
    <table>
      <thead>
        <tr>
          <th data-sort="kode">Kode <span class="sort-arrow">▲</span></th>
          <th data-sort="name">Nama Perusahaan <span class="sort-arrow">▲</span></th>
          <th>Komoditas</th>
          <th>Alamat</th>
          <th data-sort="kota">Kota <span class="sort-arrow">▲</span></th>
          <th data-sort="provinsi">Provinsi <span class="sort-arrow">▲</span></th>
          <th>Kontak</th><th>Telepon</th><th>E-mail</th>
          <th data-sort="status">Status <span class="sort-arrow">▲</span></th>
          <th data-sort="updated_at">Diperbarui <span class="sort-arrow">▲</span></th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="tbody-perusahaan">
        <tr><td colspan="12">Memuat data...</td></tr>
      </tbody>
    </table>
  </div>
</div><!-- /.table-wrap -->

<!-- ============ MODAL: FORM TAMBAH / EDIT ============ -->
<div class="modal-backdrop" id="modal-form">
  <div class="modal lg">
    <div class="modal-head">
      <div>
        <h3 id="form-title">Form</h3>
        <div class="sub" id="form-sub"></div>
      </div>
      <button type="button" class="close-btn" data-close="modal-form">✕</button>
    </div>
    <form id="company-form" novalidate>
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-field">
            <label>Nama Perusahaan <span class="req">*</span></label>
            <input id="fc-name" name="name" maxlength="255"/>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Status</label>
            <select id="fc-status" name="status">
              <?php foreach ($statusOptions as $s): ?>
                <option value="<?= esc($s) ?>"><?= esc($s) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="err"></div>
          </div>

          <div class="form-field full">
            <label>Komoditas <span class="req">*</span></label>
            <div class="chips" id="fc-komoditas"></div>
            <div class="kom-add">
              <select id="fc-komoditas-select"></select>
              <button type="button" class="btn btn-secondary btn-sm" id="btn-kom-new">+ Komoditas baru</button>
            </div>
            <div class="kom-new" id="kom-new-row" style="display:none">
              <input id="fc-kom-new-input" placeholder="Nama komoditas baru" maxlength="255"/>
              <button type="button" class="btn btn-primary btn-sm" id="btn-kom-new-save">Tambah</button>
              <button type="button" class="btn btn-secondary btn-sm" id="btn-kom-new-cancel">Batal</button>
            </div>
            <div class="kom-new-err" id="kom-new-err"></div>
            <div class="err"></div>
          </div>

          <div class="form-field">
            <label>Provinsi <span class="req">*</span></label>
            <select id="fc-provinsi" name="provinsi">
              <option value="">— Pilih provinsi —</option>
              <?php foreach ($provinceOptions as $p): ?>
                <option value="<?= esc($p) ?>"><?= esc($p) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Kabupaten / Kota</label>
            <select id="fc-kota" name="kota" disabled>
              <option value="">— Pilih provinsi dulu —</option>
            </select>
            <div class="err"></div>
          </div>

          <div class="form-field full form-section">Kontak 1</div>
          <div class="form-field">
            <label>Nama Kontak 1</label>
            <input id="fc-kontak" name="kontak" maxlength="200"/>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Nomor Telepon 1</label>
            <input id="fc-telepon" name="telepon" placeholder="+62..." maxlength="30"/>
            <div class="err"></div>
          </div>
          <div class="form-field full">
            <label>E-mail 1</label>
            <input id="fc-email" name="email" type="email" maxlength="150"/>
            <div class="err"></div>
          </div>

          <div class="form-field full form-section">Kontak 2 (opsional)</div>
          <div class="form-field">
            <label>Nama Kontak 2</label>
            <input id="fc-kontak2" name="kontak2" maxlength="200"/>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Nomor Telepon 2</label>
            <input id="fc-telepon2" name="telepon2" placeholder="+62..." maxlength="50"/>
            <div class="err"></div>
          </div>
          <div class="form-field full">
            <label>E-mail 2</label>
            <input id="fc-email2" name="email2" type="email" maxlength="150"/>
            <div class="err"></div>
          </div>

          <div class="form-field full">
            <label>Alamat</label>
            <textarea id="fc-alamat" name="alamat"></textarea>
            <div class="err"></div>
          </div>
          <div class="form-field full">
            <label>Catatan</label>
            <textarea id="fc-catatan" name="catatan"></textarea>
            <div class="err"></div>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-secondary" data-close="modal-form">Batal</button>
        <button type="submit" class="btn btn-primary" id="btn-form-save">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- ============ MODAL: DETAIL ============ -->
<div class="modal-backdrop" id="modal-detail">
  <div class="modal lg">
    <div class="modal-head">
      <div>
        <h3 id="detail-title">Detail</h3>
        <div class="sub" id="detail-sub"></div>
      </div>
      <button type="button" class="close-btn" data-close="modal-detail">✕</button>
    </div>
    <div class="modal-body" id="detail-body"></div>
    <div class="modal-foot">
      <button type="button" class="btn btn-secondary" data-close="modal-detail">Tutup</button>
      <?php if ($isAdmin): ?>
        <button type="button" class="btn btn-primary" id="btn-detail-edit">Edit</button>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ============ MODAL: IMPORT EXCEL ============ -->
<div class="modal-backdrop" id="modal-import">
  <div class="modal lg">
    <div class="modal-head">
      <div>
        <h3>Import dari Excel</h3>
        <div class="sub" id="import-sub">Unggah file .xlsx, periksa dulu sebelum disimpan</div>
      </div>
      <button type="button" class="close-btn" data-close="modal-import">✕</button>
    </div>
    <div class="modal-body">

      <div id="import-step-upload">
        <label class="import-drop" id="import-drop">
          <input type="file" id="import-file" accept=".xlsx"/>
          <div>📄 Klik untuk pilih file .xlsx, atau tarik ke sini</div>
          <div class="import-filename" id="import-filename">Belum ada file dipilih</div>
        </label>
        <div class="import-hint">
          Header kolom yang dikenali: Nama Perusahaan, Komoditas, Alamat, Kota, Provinsi,
          Nama Kontak 1/2, Telepon 1/2, E-mail 1/2. Nama kolom boleh sedikit berbeda.
          Maksimal 5&nbsp;MB, 1.000 baris.
        </div>
      </div>

      <div id="import-step-preview" style="display:none">
        <div class="import-summary">
          <div class="import-stat ok"><b id="sum-valid">0</b>Siap diimpor</div>
          <div class="import-stat skip"><b id="sum-skipped">0</b>Dilewati (sudah ada)</div>
          <div class="import-stat bad"><b id="sum-invalid">0</b>Bermasalah</div>
        </div>

        <div id="block-invalid" style="display:none">
          <div class="import-section-title">Baris bermasalah (tidak ikut diimpor)</div>
          <div class="import-list bad" id="list-invalid"></div>
        </div>

        <div id="block-warnings" style="display:none">
          <div class="import-section-title">Peringatan (tetap diimpor, field terkait dikosongkan)</div>
          <div class="import-list warn" id="list-warnings"></div>
        </div>

        <div id="block-skipped" style="display:none">
          <div class="import-section-title">Dilewati — sudah ada di database</div>
          <div class="import-list" id="list-skipped"></div>
        </div>

        <div id="block-newkom" style="display:none">
          <div class="import-section-title">Komoditas baru yang akan dibuat</div>
          <div class="import-list new" id="list-newkom"></div>
        </div>

        <div id="block-headerinfo" style="display:none">
          <div class="import-section-title">Kolom yang tidak dikenali (diabaikan)</div>
          <div class="import-list" id="list-unrecognized"></div>
        </div>
      </div>

    </div>
    <div class="modal-foot">
      <button type="button" class="btn btn-secondary" data-close="modal-import">Batal</button>
      <button type="button" class="btn btn-primary" id="btn-import-check">Periksa File</button>
      <button type="button" class="btn btn-primary" id="btn-import-confirm" style="display:none">Impor Sekarang</button>
    </div>
  </div>
</div>

<!-- ============ MODAL: KONFIRMASI HAPUS ============ -->
<div class="modal-backdrop" id="modal-confirm">
  <div class="modal sm">
    <div class="modal-head">
      <h3 id="confirm-title">Konfirmasi</h3>
      <button type="button" class="close-btn" data-close="modal-confirm">✕</button>
    </div>
    <div class="modal-body">
      <p id="confirm-msg" style="font-size:14px;color:var(--c-text-soft)"></p>
    </div>
    <div class="modal-foot">
      <button type="button" class="btn btn-secondary" data-close="modal-confirm">Batal</button>
      <button type="button" class="btn btn-danger" id="btn-confirm-ok">Hapus</button>
    </div>
  </div>
</div>

<script>
  window.COMPANY_CFG = {
    isAdmin: <?= $isAdmin ? 'true' : 'false' ?>,
    urls: {
      data:   '<?= site_url('perusahaan/data') ?>',
      store:  '<?= site_url('perusahaan/store') ?>',
      update: '<?= site_url('perusahaan/update') ?>/',
      remove: '<?= site_url('perusahaan/delete') ?>/',
      komoditasStore: '<?= site_url('komoditas/store') ?>',
      importPreview: '<?= site_url('perusahaan/import/preview') ?>',
      importCommit: '<?= site_url('perusahaan/import/commit') ?>',
    },
    komoditas: <?= json_encode($komoditas, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
    wilayah: <?= json_encode($wilayah, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
    csrfHeader: '<?= csrf_header() ?>',
    csrfToken:  '<?= csrf_hash() ?>',
  };
</script>
<script src="<?= base_url('assets/js/companies.js') ?>"></script>

<?= $this->endSection() ?>