<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<style>
  .usage-count{font-variant-numeric:tabular-nums;color:var(--c-text-soft)}
  .usage-count.zero{color:var(--c-text-mute)}
</style>

<div class="page-header">
  <div>
    <h2>Master Komoditas</h2>
    <div class="desc">Daftar komoditas yang dipakai di Master Perusahaan</div>
  </div>
  <div class="actions">
    <?php if ($isAdmin): ?>
      <button class="btn btn-primary" id="btn-add-komoditas">+ Tambah Komoditas</button>
    <?php endif; ?>
  </div>
</div>

<div class="table-wrap">
  <div class="table-tools">
    <div class="input-search">
      <span>🔍</span>
      <input id="search-komoditas" placeholder="Cari nama komoditas..."/>
    </div>
  </div>

  <div class="table-scroll">
    <table>
      <thead>
        <tr>
          <th>Nama Komoditas</th>
          <th style="text-align:right">Dipakai Perusahaan</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="tbody-komoditas">
        <tr><td colspan="3">Memuat data...</td></tr>
      </tbody>
    </table>
  </div>
</div>

<!-- ============ MODAL: TAMBAH / EDIT ============ -->
<div class="modal-backdrop" id="modal-form">
  <div class="modal sm">
    <div class="modal-head">
      <h3 id="form-title">Tambah Komoditas</h3>
      <button type="button" class="close-btn" data-close="modal-form">✕</button>
    </div>
    <form id="komoditas-form">
      <div class="modal-body">
        <div class="form-field">
          <label>Nama Komoditas <span class="req">*</span></label>
          <input id="fk-name" name="name" maxlength="255"/>
          <div class="err"></div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-secondary" data-close="modal-form">Batal</button>
        <button type="submit" class="btn btn-primary" id="btn-form-save">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- ============ MODAL: KONFIRMASI HAPUS ============ -->
<div class="modal-backdrop" id="modal-confirm">
  <div class="modal sm">
    <div class="modal-head">
      <h3>Hapus komoditas?</h3>
      <button type="button" class="close-btn" data-close="modal-confirm">✕</button>
    </div>
    <div class="modal-body">
      <p id="confirm-msg" style="font-size:14px;color:var(--c-text-soft)"></p>
    </div>
    <div class="modal-foot">
      <button type="button" class="btn btn-secondary" data-close="modal-confirm">Batal</button>
      <button type="button" class="btn btn-danger" id="btn-confirm-ok">Hapus</button>
    </div>
  </div>
</div>

<script>
  window.KOMODITAS_CFG = {
    isAdmin: <?= $isAdmin ? 'true' : 'false' ?>,
    urls: {
      data:   '<?= site_url('komoditas/data') ?>',
      store:  '<?= site_url('komoditas/store') ?>',
      update: '<?= site_url('komoditas/update') ?>/',
      remove: '<?= site_url('komoditas/delete') ?>/',
    },
    csrfHeader: '<?= csrf_header() ?>',
    csrfToken:  '<?= csrf_hash() ?>',
  };
</script>
<script src="<?= base_url('assets/js/komoditas.js') ?>"></script>

<?= $this->endSection() ?>