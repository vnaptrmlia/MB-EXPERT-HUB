<?php

namespace App\Controllers;

use App\Models\KomoditasModel;

/**
 * Master Komoditas. Akses ikut pola Companies: siapa saja yang login boleh
 * membuka halaman & melihat daftar, tambah/ganti-nama/hapus hanya Admin
 * (dicek di sini, bukan disembunyikan di View).
 *
 * Tidak ada kolom cache di companies.komoditas (keputusan produk: sumber
 * kebenaran cuma pivot company_komoditas). Karena itu ganti nama di sini
 * OTOMATIS langsung terlihat di mana pun komoditas ditampilkan — Controller
 * lain selalu JOIN ke tabel ini, tidak pernah menyalin nilainya.
 */
class KomoditasController extends BaseController
{
    private KomoditasModel $model;

    public function __construct()
    {
        $this->model = new KomoditasModel();
    }

    public function index()
    {
        return view('komoditas/index', [
            'crumb'   => 'Master Komoditas',
            'isAdmin' => session()->get('role') === 'Admin',
        ]);
    }

    // Daftar komoditas + jumlah perusahaan yang memakainya (dari pivot,
    // dihitung live — bukan angka yang disimpan/di-cache).
    public function data()
    {
        $rows = \Config\Database::connect()
            ->table('komoditas k')
            ->select('k.id, k.name, COUNT(ck.company_id) AS usage_count')
            ->join('company_komoditas ck', 'ck.komoditas_id = k.id', 'left')
            ->groupBy('k.id, k.name')
            ->orderBy('k.name', 'ASC')
            ->get()->getResultArray();

        foreach ($rows as &$r) {
            $r['id']          = (int) $r['id'];
            $r['usage_count'] = (int) $r['usage_count'];
        }
        unset($r);

        return $this->response->setJSON(['data' => $rows]);
    }

    // Dipakai juga oleh tombol "+ Komoditas baru" di form perusahaan.
    public function store()
    {
        if ($denied = $this->denyNonAdmin('menambah')) {
            return $denied;
        }

        $name = KomoditasModel::normalize($this->request->getPost('name'));
        $id   = $this->model->insert(['name' => $name]);

        if (! $id) {
            return $this->invalid($this->model->errors());
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Komoditas ditambahkan',
            'data'    => ['id' => (int) $id, 'name' => $name],
        ]);
    }

    // Ganti nama. Tidak menyentuh companies atau company_komoditas sama
    // sekali — semua tempat yang menampilkan nama komoditas selalu JOIN
    // live ke tabel ini, jadi perubahan langsung terlihat di mana pun.
    public function update($id)
    {
        if ($denied = $this->denyNonAdmin('mengubah')) {
            return $denied;
        }

        $id = (int) $id;
        if ($this->model->find($id) === null) {
            return $this->notFound();
        }

        $name = KomoditasModel::normalize($this->request->getPost('name'));

        if (! $this->model->update($id, ['name' => $name])) {
            return $this->invalid($this->model->errors());
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Komoditas diperbarui',
            'data'    => ['id' => $id, 'name' => $name],
        ]);
    }

    // Ditolak kalau masih dipakai perusahaan mana pun (juga dijaga FK
    // ON DELETE RESTRICT di database; di sini dicek dulu supaya pesannya
    // ramah, bukan error SQL mentah).
    public function delete($id)
    {
        if ($denied = $this->denyNonAdmin('menghapus')) {
            return $denied;
        }

        $id = (int) $id;
        if ($this->model->find($id) === null) {
            return $this->notFound();
        }

        $usedBy = \Config\Database::connect()
            ->table('company_komoditas')
            ->where('komoditas_id', $id)
            ->countAllResults();

        if ($usedBy > 0) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => "Komoditas ini masih dipakai {$usedBy} perusahaan, tidak bisa dihapus.",
            ]);
        }

        $this->model->delete($id);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Komoditas dihapus',
        ]);
    }

    private function denyNonAdmin(string $aksi)
    {
        if (session()->get('role') === 'Admin') {
            return null;
        }
        return $this->response->setStatusCode(403)->setJSON([
            'success' => false,
            'message' => "Hanya Admin yang dapat {$aksi} komoditas.",
        ]);
    }

    private function invalid(array $errors)
    {
        return $this->response->setStatusCode(422)->setJSON([
            'success' => false,
            'message' => 'Validasi gagal.',
            'errors'  => $errors,
        ]);
    }

    private function notFound()
    {
        return $this->response->setStatusCode(404)->setJSON([
            'success' => false,
            'message' => 'Komoditas tidak ditemukan.',
        ]);
    }
}