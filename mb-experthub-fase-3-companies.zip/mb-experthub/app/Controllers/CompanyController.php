<?php

namespace App\Controllers;

use App\Libraries\Wilayah;
use App\Models\CompanyModel;

class CompanyController extends BaseController
{
    protected CompanyModel $companyModel;

    public function __construct()
    {
        $this->companyModel = new CompanyModel();
    }

    // Render halaman shell — nggak bawa data, data-nya diambil View
    // lewat fetch() ke data() di bawah.
    public function index()
    {
        return view('companies/index', [
            'crumb'           => 'Master Perusahaan',
            'statusOptions'   => CompanyModel::STATUS_OPTIONS,
            'provinceOptions' => array_keys(CompanyModel::PROVINCE_CODES),
            'wilayah'         => Wilayah::all(),
            'isAdmin'         => session()->get('role') === 'Admin',
        ]);
    }

    // Endpoint JSON — dipanggil AJAX dari View buat isi tabel.
    public function data()
    {
        $companies = $this->companyModel->orderBy('name', 'ASC')->findAll();

        return $this->response->setJSON([
            'data' => $companies,
        ]);
    }

    public function store()
    {
        if (session()->get('role') !== 'Admin') {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Hanya Admin yang dapat menambah data.',
            ]);
        }

        $data = [
            'name'      => $this->request->getPost('name'),
            'komoditas' => $this->request->getPost('komoditas'),
            'alamat'    => $this->request->getPost('alamat'),
            'kota'      => $this->request->getPost('kota'),
            'provinsi'  => $this->request->getPost('provinsi'),
            'kontak'    => $this->request->getPost('kontak'),
            'telepon'   => $this->request->getPost('telepon'),
            'email'     => $this->request->getPost('email'),
            'status'    => $this->request->getPost('status'),
            'catatan'   => $this->request->getPost('catatan'),
        ];

        if ($err = $this->kotaError($data['provinsi'], $data['kota'])) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => 'Validasi gagal.',
                'errors'  => ['kota' => $err],
            ]);
        }

        try {
            if (! $this->companyModel->insert($data)) {
                return $this->response->setStatusCode(422)->setJSON([
                    'success' => false,
                    'message' => 'Validasi gagal.',
                    'errors'  => $this->companyModel->errors(),
                ]);
            }
        } catch (\RuntimeException $e) {
            // Cuma kena kalau ada yang bypass <select> dan kirim provinsi
            // yang nggak ada di PROVINCE_CODES lewat request langsung.
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => $e->getMessage(),
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Perusahaan baru ditambahkan',
        ]);
    }

    public function delete($id)
    {
        if (session()->get('role') !== 'Admin') {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Hanya Admin yang dapat menghapus data.',
            ]);
        }

        $company = $this->companyModel->find($id);
        if ($company === null) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Data tidak ditemukan.',
            ]);
        }

        $this->companyModel->delete($id);

        // Catatan: FK project.company_id (ON DELETE SET NULL) otomatis
        // dijalankan MySQL sendiri di level DB — kita nggak perlu nulis
        // logic manual buat "bersihin" project yang terkait, itu udah
        // ditangani constraint yang kita bikin di Fase 1.

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Perusahaan dihapus',
        ]);
    }

    public function update($id)
    {
        if (session()->get('role') !== 'Admin') {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Hanya Admin yang dapat mengubah data.',
            ]);
        }

        $existing = $this->companyModel->find($id);
        if ($existing === null) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Data tidak ditemukan.',
            ]);
        }

        $data = [
            'name'      => $this->request->getPost('name'),
            'komoditas' => $this->request->getPost('komoditas'),
            'alamat'    => $this->request->getPost('alamat'),
            'kota'      => $this->request->getPost('kota'),
            'provinsi'  => $this->request->getPost('provinsi'),
            'kontak'    => $this->request->getPost('kontak'),
            'telepon'   => $this->request->getPost('telepon'),
            'email'     => $this->request->getPost('email'),
            'status'    => $this->request->getPost('status'),
            'catatan'   => $this->request->getPost('catatan'),
        ];

        // find() bisa array atau objek tergantung $returnType model
        $old = (array) $existing;
        // Kota lama yang di luar daftar hanya dimaafkan bila provinsi tidak berubah
        $keepKota = (($old['provinsi'] ?? null) === $data['provinsi']) ? ($old['kota'] ?? null) : null;

        if ($err = $this->kotaError($data['provinsi'], $data['kota'], $keepKota)) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => 'Validasi gagal.',
                'errors'  => ['kota' => $err],
            ]);
        }

        try {
            if (! $this->companyModel->update($id, $data)) {
                return $this->response->setStatusCode(422)->setJSON([
                    'success' => false,
                    'message' => 'Validasi gagal.',
                    'errors'  => $this->companyModel->errors(),
                ]);
            }
        } catch (\RuntimeException $e) {
            return $this->response->setStatusCode(422)->setJSON([
                'success' => false,
                'message' => $e->getMessage(),
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Data perusahaan diperbarui',
        ]);
    }

    // Kota (opsional) harus termasuk provinsi yang dipilih. Nilai lama yang
    // tidak ada di daftar tetap boleh selama tidak diubah ($existingKota).
    private function kotaError(?string $provinsi, ?string $kota, ?string $existingKota = null): ?string
    {
        $kota = trim((string) $kota);
        if ($kota === '') {
            return null;
        }
        if ($existingKota !== null && $kota === $existingKota) {
            return null;
        }
        return Wilayah::isValid($provinsi, $kota)
            ? null
            : 'Kabupaten/kota tidak sesuai dengan provinsi yang dipilih.';
    }

}