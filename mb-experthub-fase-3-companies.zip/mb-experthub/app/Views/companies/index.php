<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="page-header">
  <div>
    <h2>Master Perusahaan</h2>
    <div class="desc">Database perusahaan yang dapat dihubungi</div>
  </div>
  <div class="actions">
    <?php if ($isAdmin): ?>
      <button class="btn btn-primary" id="btn-add-company">+ Tambah Perusahaan</button>
    <?php endif; ?>
  </div>
</div>

<div class="table-wrap">
  <div class="table-tools">
    <div class="input-search">
      <span>🔍</span>
      <input id="search-perusahaan" placeholder="Cari nama, komoditas, kota..."/>
    </div>
    <select class="input" id="filter-komoditas"><option value="">Semua Komoditas</option></select>
    <select class="input" id="filter-status">
      <option value="">Semua Status</option>
      <?php foreach ($statusOptions as $s): ?>
        <option value="<?= esc($s) ?>"><?= esc($s) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="input" id="filter-provinsi">
      <option value="">Semua Provinsi</option>
      <?php foreach ($provinceOptions as $p): ?>
        <option value="<?= esc($p) ?>"><?= esc($p) ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="table-scroll">
    <table>
      <thead>
        <tr>
          <th>Kode</th><th>Nama Perusahaan</th><th>Komoditas</th><th>Alamat</th>
          <th>Kota</th><th>Provinsi</th><th>Kontak</th><th>Telepon</th>
          <th>E-mail</th><th>Status</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody id="tbody-perusahaan">
        <tr><td colspan="11">Memuat data...</td></tr>
      </tbody>
    </table>
  </div>
</div><!-- /.table-wrap -->

<!-- ============ MODAL: FORM TAMBAH / EDIT ============ -->
<div class="modal-backdrop" id="modal-form">
  <div class="modal lg">
    <div class="modal-head">
      <div>
        <h3 id="form-title">Form</h3>
        <div class="sub" id="form-sub"></div>
      </div>
      <button type="button" class="close-btn" data-close="modal-form">✕</button>
    </div>
    <form id="company-form" novalidate>
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-field">
            <label>Nama Perusahaan <span class="req">*</span></label>
            <input id="fc-name" name="name" maxlength="255"/>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Komoditas <span class="req">*</span></label>
            <input id="fc-komoditas" name="komoditas" list="dl-komoditas" maxlength="255"/>
            <datalist id="dl-komoditas"></datalist>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Provinsi <span class="req">*</span></label>
            <select id="fc-provinsi" name="provinsi">
              <option value="">— Pilih provinsi —</option>
              <?php foreach ($provinceOptions as $p): ?>
                <option value="<?= esc($p) ?>"><?= esc($p) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Kabupaten / Kota</label>
            <select id="fc-kota" name="kota" disabled>
              <option value="">— Pilih provinsi dulu —</option>
            </select>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Status</label>
            <select id="fc-status" name="status">
              <?php foreach ($statusOptions as $s): ?>
                <option value="<?= esc($s) ?>"><?= esc($s) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Nama Kontak</label>
            <input id="fc-kontak" name="kontak" maxlength="255"/>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>Nomor Telepon</label>
            <input id="fc-telepon" name="telepon" placeholder="+62..." maxlength="50"/>
            <div class="err"></div>
          </div>
          <div class="form-field">
            <label>E-mail</label>
            <input id="fc-email" name="email" type="email" maxlength="255"/>
            <div class="err"></div>
          </div>
          <div class="form-field full">
            <label>Alamat</label>
            <textarea id="fc-alamat" name="alamat"></textarea>
            <div class="err"></div>
          </div>
          <div class="form-field full">
            <label>Catatan</label>
            <textarea id="fc-catatan" name="catatan"></textarea>
            <div class="err"></div>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-secondary" data-close="modal-form">Batal</button>
        <button type="submit" class="btn btn-primary" id="btn-form-save">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- ============ MODAL: DETAIL ============ -->
<div class="modal-backdrop" id="modal-detail">
  <div class="modal lg">
    <div class="modal-head">
      <div>
        <h3 id="detail-title">Detail</h3>
        <div class="sub" id="detail-sub"></div>
      </div>
      <button type="button" class="close-btn" data-close="modal-detail">✕</button>
    </div>
    <div class="modal-body" id="detail-body"></div>
    <div class="modal-foot">
      <button type="button" class="btn btn-secondary" data-close="modal-detail">Tutup</button>
      <?php if ($isAdmin): ?>
        <button type="button" class="btn btn-primary" id="btn-detail-edit">Edit</button>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ============ MODAL: KONFIRMASI HAPUS ============ -->
<div class="modal-backdrop" id="modal-confirm">
  <div class="modal sm">
    <div class="modal-head">
      <h3 id="confirm-title">Konfirmasi</h3>
      <button type="button" class="close-btn" data-close="modal-confirm">✕</button>
    </div>
    <div class="modal-body">
      <p id="confirm-msg" style="font-size:14px;color:var(--c-text-soft)"></p>
    </div>
    <div class="modal-foot">
      <button type="button" class="btn btn-secondary" data-close="modal-confirm">Batal</button>
      <button type="button" class="btn btn-danger" id="btn-confirm-ok">Hapus</button>
    </div>
  </div>
</div>

<script>
  window.COMPANY_CFG = {
    isAdmin: <?= $isAdmin ? 'true' : 'false' ?>,
    urls: {
      data:   '<?= site_url('perusahaan/data') ?>',
      store:  '<?= site_url('perusahaan/store') ?>',
      update: '<?= site_url('perusahaan/update') ?>/',
      remove: '<?= site_url('perusahaan/delete') ?>/',
    },
    wilayah: <?= json_encode($wilayah, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
    csrfHeader: '<?= csrf_header() ?>',
    csrfToken:  '<?= csrf_hash() ?>',
  };
</script>
<script src="<?= base_url('assets/js/companies.js') ?>"></script>

<?= $this->endSection() ?>