<?php

namespace App\Libraries;

/**
 * Daftar provinsi -> kabupaten/kota (38 provinsi, 514 kabupaten/kota).
 *
 * Sumber dasar: kode wilayah Kemendagri (via paket npm territory-indonesia).
 * Provinsi pemekaran Papua 2022 (Papua Selatan, Papua Tengah, Papua Pegunungan,
 * Papua Barat Daya) dipetakan manual dari data lama Papua / Papua Barat.
 *
 * Satu-satunya sumber untuk dropdown Kota di form DAN validasi di Controller.
 * Kunci provinsi HARUS sama persis dengan kunci CompanyModel::PROVINCE_CODES.
 */
class Wilayah
{
    public const DATA = [
        'Aceh' => [
            'Kabupaten Aceh Barat', 'Kabupaten Aceh Barat Daya', 'Kabupaten Aceh Besar',
            'Kabupaten Aceh Jaya', 'Kabupaten Aceh Selatan', 'Kabupaten Aceh Singkil',
            'Kabupaten Aceh Tamiang', 'Kabupaten Aceh Tengah', 'Kabupaten Aceh Tenggara',
            'Kabupaten Aceh Timur', 'Kabupaten Aceh Utara', 'Kabupaten Bener Meriah',
            'Kabupaten Bireuen', 'Kabupaten Gayo Lues', 'Kabupaten Nagan Raya',
            'Kabupaten Pidie', 'Kabupaten Pidie Jaya', 'Kabupaten Simeulue',
            'Kota Banda Aceh', 'Kota Langsa', 'Kota Lhokseumawe',
            'Kota Sabang', 'Kota Subulussalam',
        ],
        'Bali' => [
            'Kabupaten Badung', 'Kabupaten Bangli', 'Kabupaten Buleleng',
            'Kabupaten Gianyar', 'Kabupaten Jembrana', 'Kabupaten Karang Asem',
            'Kabupaten Klungkung', 'Kabupaten Tabanan', 'Kota Denpasar',
        ],
        'Banten' => [
            'Kabupaten Lebak', 'Kabupaten Pandeglang', 'Kabupaten Serang',
            'Kabupaten Tangerang', 'Kota Cilegon', 'Kota Serang',
            'Kota Tangerang', 'Kota Tangerang Selatan',
        ],
        'Bengkulu' => [
            'Kabupaten Bengkulu Selatan', 'Kabupaten Bengkulu Tengah', 'Kabupaten Bengkulu Utara',
            'Kabupaten Kaur', 'Kabupaten Kepahiang', 'Kabupaten Lebong',
            'Kabupaten Mukomuko', 'Kabupaten Rejang Lebong', 'Kabupaten Seluma',
            'Kota Bengkulu',
        ],
        'DI Yogyakarta' => [
            'Kabupaten Bantul', 'Kabupaten Gunung Kidul', 'Kabupaten Kulon Progo',
            'Kabupaten Sleman', 'Kota Yogyakarta',
        ],
        'DKI Jakarta' => [
            'Kabupaten Kepulauan Seribu', 'Kota Jakarta Barat', 'Kota Jakarta Pusat',
            'Kota Jakarta Selatan', 'Kota Jakarta Timur', 'Kota Jakarta Utara',
        ],
        'Gorontalo' => [
            'Kabupaten Boalemo', 'Kabupaten Bone Bolango', 'Kabupaten Gorontalo',
            'Kabupaten Gorontalo Utara', 'Kabupaten Pohuwato', 'Kota Gorontalo',
        ],
        'Jambi' => [
            'Kabupaten Batang Hari', 'Kabupaten Bungo', 'Kabupaten Kerinci',
            'Kabupaten Merangin', 'Kabupaten Muaro Jambi', 'Kabupaten Sarolangun',
            'Kabupaten Tanjung Jabung Barat', 'Kabupaten Tanjung Jabung Timur', 'Kabupaten Tebo',
            'Kota Jambi', 'Kota Sungai Penuh',
        ],
        'Jawa Barat' => [
            'Kabupaten Bandung', 'Kabupaten Bandung Barat', 'Kabupaten Bekasi',
            'Kabupaten Bogor', 'Kabupaten Ciamis', 'Kabupaten Cianjur',
            'Kabupaten Cirebon', 'Kabupaten Garut', 'Kabupaten Indramayu',
            'Kabupaten Karawang', 'Kabupaten Kuningan', 'Kabupaten Majalengka',
            'Kabupaten Pangandaran', 'Kabupaten Purwakarta', 'Kabupaten Subang',
            'Kabupaten Sukabumi', 'Kabupaten Sumedang', 'Kabupaten Tasikmalaya',
            'Kota Bandung', 'Kota Banjar', 'Kota Bekasi',
            'Kota Bogor', 'Kota Cimahi', 'Kota Cirebon',
            'Kota Depok', 'Kota Sukabumi', 'Kota Tasikmalaya',
        ],
        'Jawa Tengah' => [
            'Kabupaten Banjarnegara', 'Kabupaten Banyumas', 'Kabupaten Batang',
            'Kabupaten Blora', 'Kabupaten Boyolali', 'Kabupaten Brebes',
            'Kabupaten Cilacap', 'Kabupaten Demak', 'Kabupaten Grobogan',
            'Kabupaten Jepara', 'Kabupaten Karanganyar', 'Kabupaten Kebumen',
            'Kabupaten Kendal', 'Kabupaten Klaten', 'Kabupaten Kudus',
            'Kabupaten Magelang', 'Kabupaten Pati', 'Kabupaten Pekalongan',
            'Kabupaten Pemalang', 'Kabupaten Purbalingga', 'Kabupaten Purworejo',
            'Kabupaten Rembang', 'Kabupaten Semarang', 'Kabupaten Sragen',
            'Kabupaten Sukoharjo', 'Kabupaten Tegal', 'Kabupaten Temanggung',
            'Kabupaten Wonogiri', 'Kabupaten Wonosobo', 'Kota Magelang',
            'Kota Pekalongan', 'Kota Salatiga', 'Kota Semarang',
            'Kota Surakarta', 'Kota Tegal',
        ],
        'Jawa Timur' => [
            'Kabupaten Bangkalan', 'Kabupaten Banyuwangi', 'Kabupaten Blitar',
            'Kabupaten Bojonegoro', 'Kabupaten Bondowoso', 'Kabupaten Gresik',
            'Kabupaten Jember', 'Kabupaten Jombang', 'Kabupaten Kediri',
            'Kabupaten Lamongan', 'Kabupaten Lumajang', 'Kabupaten Madiun',
            'Kabupaten Magetan', 'Kabupaten Malang', 'Kabupaten Mojokerto',
            'Kabupaten Nganjuk', 'Kabupaten Ngawi', 'Kabupaten Pacitan',
            'Kabupaten Pamekasan', 'Kabupaten Pasuruan', 'Kabupaten Ponorogo',
            'Kabupaten Probolinggo', 'Kabupaten Sampang', 'Kabupaten Sidoarjo',
            'Kabupaten Situbondo', 'Kabupaten Sumenep', 'Kabupaten Trenggalek',
            'Kabupaten Tuban', 'Kabupaten Tulungagung', 'Kota Batu',
            'Kota Blitar', 'Kota Kediri', 'Kota Madiun',
            'Kota Malang', 'Kota Mojokerto', 'Kota Pasuruan',
            'Kota Probolinggo', 'Kota Surabaya',
        ],
        'Kalimantan Barat' => [
            'Kabupaten Bengkayang', 'Kabupaten Kapuas Hulu', 'Kabupaten Kayong Utara',
            'Kabupaten Ketapang', 'Kabupaten Kubu Raya', 'Kabupaten Landak',
            'Kabupaten Melawi', 'Kabupaten Mempawah', 'Kabupaten Sambas',
            'Kabupaten Sanggau', 'Kabupaten Sekadau', 'Kabupaten Sintang',
            'Kota Pontianak', 'Kota Singkawang',
        ],
        'Kalimantan Selatan' => [
            'Kabupaten Balangan', 'Kabupaten Banjar', 'Kabupaten Barito Kuala',
            'Kabupaten Hulu Sungai Selatan', 'Kabupaten Hulu Sungai Tengah', 'Kabupaten Hulu Sungai Utara',
            'Kabupaten Kota Baru', 'Kabupaten Tabalong', 'Kabupaten Tanah Bumbu',
            'Kabupaten Tanah Laut', 'Kabupaten Tapin', 'Kota Banjar Baru',
            'Kota Banjarmasin',
        ],
        'Kalimantan Tengah' => [
            'Kabupaten Barito Selatan', 'Kabupaten Barito Timur', 'Kabupaten Barito Utara',
            'Kabupaten Gunung Mas', 'Kabupaten Kapuas', 'Kabupaten Katingan',
            'Kabupaten Kotawaringin Barat', 'Kabupaten Kotawaringin Timur', 'Kabupaten Lamandau',
            'Kabupaten Murung Raya', 'Kabupaten Pulang Pisau', 'Kabupaten Seruyan',
            'Kabupaten Sukamara', 'Kota Palangka Raya',
        ],
        'Kalimantan Timur' => [
            'Kabupaten Berau', 'Kabupaten Kutai Barat', 'Kabupaten Kutai Kartanegara',
            'Kabupaten Kutai Timur', 'Kabupaten Mahakam Hulu', 'Kabupaten Paser',
            'Kabupaten Penajam Paser Utara', 'Kota Balikpapan', 'Kota Bontang',
            'Kota Samarinda',
        ],
        'Kalimantan Utara' => [
            'Kabupaten Bulungan', 'Kabupaten Malinau', 'Kabupaten Nunukan',
            'Kabupaten Tana Tidung', 'Kota Tarakan',
        ],
        'Kepulauan Bangka Belitung' => [
            'Kabupaten Bangka', 'Kabupaten Bangka Barat', 'Kabupaten Bangka Selatan',
            'Kabupaten Bangka Tengah', 'Kabupaten Belitung', 'Kabupaten Belitung Timur',
            'Kota Pangkal Pinang',
        ],
        'Kepulauan Riau' => [
            'Kabupaten Bintan', 'Kabupaten Karimun', 'Kabupaten Kepulauan Anambas',
            'Kabupaten Lingga', 'Kabupaten Natuna', 'Kota Batam',
            'Kota Tanjung Pinang',
        ],
        'Lampung' => [
            'Kabupaten Lampung Barat', 'Kabupaten Lampung Selatan', 'Kabupaten Lampung Tengah',
            'Kabupaten Lampung Timur', 'Kabupaten Lampung Utara', 'Kabupaten Mesuji',
            'Kabupaten Pesawaran', 'Kabupaten Pesisir Barat', 'Kabupaten Pringsewu',
            'Kabupaten Tanggamus', 'Kabupaten Tulang Bawang Barat', 'Kabupaten Tulangbawang',
            'Kabupaten Way Kanan', 'Kota Bandar Lampung', 'Kota Metro',
        ],
        'Maluku' => [
            'Kabupaten Buru', 'Kabupaten Buru Selatan', 'Kabupaten Kepulauan Aru',
            'Kabupaten Maluku Barat Daya', 'Kabupaten Maluku Tengah', 'Kabupaten Maluku Tenggara',
            'Kabupaten Maluku Tenggara Barat', 'Kabupaten Seram Bagian Barat', 'Kabupaten Seram Bagian Timur',
            'Kota Ambon', 'Kota Tual',
        ],
        'Maluku Utara' => [
            'Kabupaten Halmahera Barat', 'Kabupaten Halmahera Selatan', 'Kabupaten Halmahera Tengah',
            'Kabupaten Halmahera Timur', 'Kabupaten Halmahera Utara', 'Kabupaten Kepulauan Sula',
            'Kabupaten Pulau Morotai', 'Kabupaten Pulau Taliabu', 'Kota Ternate',
            'Kota Tidore Kepulauan',
        ],
        'Nusa Tenggara Barat' => [
            'Kabupaten Bima', 'Kabupaten Dompu', 'Kabupaten Lombok Barat',
            'Kabupaten Lombok Tengah', 'Kabupaten Lombok Timur', 'Kabupaten Lombok Utara',
            'Kabupaten Sumbawa', 'Kabupaten Sumbawa Barat', 'Kota Bima',
            'Kota Mataram',
        ],
        'Nusa Tenggara Timur' => [
            'Kabupaten Alor', 'Kabupaten Belu', 'Kabupaten Ende',
            'Kabupaten Flores Timur', 'Kabupaten Kupang', 'Kabupaten Lembata',
            'Kabupaten Malaka', 'Kabupaten Manggarai', 'Kabupaten Manggarai Barat',
            'Kabupaten Manggarai Timur', 'Kabupaten Nagekeo', 'Kabupaten Ngada',
            'Kabupaten Rote Ndao', 'Kabupaten Sabu Raijua', 'Kabupaten Sikka',
            'Kabupaten Sumba Barat', 'Kabupaten Sumba Barat Daya', 'Kabupaten Sumba Tengah',
            'Kabupaten Sumba Timur', 'Kabupaten Timor Tengah Selatan', 'Kabupaten Timor Tengah Utara',
            'Kota Kupang',
        ],
        'Papua' => [
            'Kabupaten Biak Numfor', 'Kabupaten Jayapura', 'Kabupaten Keerom',
            'Kabupaten Kepulauan Yapen', 'Kabupaten Mamberamo Raya', 'Kabupaten Sarmi',
            'Kabupaten Supiori', 'Kabupaten Waropen', 'Kota Jayapura',
        ],
        'Papua Barat' => [
            'Kabupaten Fak-Fak', 'Kabupaten Kaimana', 'Kabupaten Manokwari',
            'Kabupaten Manokwari Selatan', 'Kabupaten Pegunungan Arfak', 'Kabupaten Teluk Bintuni',
            'Kabupaten Teluk Wondama',
        ],
        'Papua Barat Daya' => [
            'Kabupaten Maybrat', 'Kabupaten Raja Ampat', 'Kabupaten Sorong',
            'Kabupaten Sorong Selatan', 'Kabupaten Tambrauw', 'Kota Sorong',
        ],
        'Papua Pegunungan' => [
            'Kabupaten Jayawijaya', 'Kabupaten Lanny Jaya', 'Kabupaten Mamberamo Tengah',
            'Kabupaten Nduga', 'Kabupaten Pegunungan Bintang', 'Kabupaten Tolikara',
            'Kabupaten Yahukimo', 'Kabupaten Yalimo',
        ],
        'Papua Selatan' => [
            'Kabupaten Asmat', 'Kabupaten Boven Digoel', 'Kabupaten Mappi',
            'Kabupaten Merauke',
        ],
        'Papua Tengah' => [
            'Kabupaten Deiyai', 'Kabupaten Dogiyai', 'Kabupaten Intan Jaya',
            'Kabupaten Mimika', 'Kabupaten Nabire', 'Kabupaten Paniai',
            'Kabupaten Puncak', 'Kabupaten Puncak Jaya',
        ],
        'Riau' => [
            'Kabupaten Bengkalis', 'Kabupaten Indragiri Hilir', 'Kabupaten Indragiri Hulu',
            'Kabupaten Kampar', 'Kabupaten Kepulauan Meranti', 'Kabupaten Kuantan Singingi',
            'Kabupaten Pelalawan', 'Kabupaten Rokan Hilir', 'Kabupaten Rokan Hulu',
            'Kabupaten Siak', 'Kota Dumai', 'Kota Pekanbaru',
        ],
        'Sulawesi Barat' => [
            'Kabupaten Majene', 'Kabupaten Mamasa', 'Kabupaten Mamuju',
            'Kabupaten Mamuju Tengah', 'Kabupaten Mamuju Utara', 'Kabupaten Polewali Mandar',
        ],
        'Sulawesi Selatan' => [
            'Kabupaten Bantaeng', 'Kabupaten Barru', 'Kabupaten Bone',
            'Kabupaten Bulukumba', 'Kabupaten Enrekang', 'Kabupaten Gowa',
            'Kabupaten Jeneponto', 'Kabupaten Kepulauan Selayar', 'Kabupaten Luwu',
            'Kabupaten Luwu Timur', 'Kabupaten Luwu Utara', 'Kabupaten Maros',
            'Kabupaten Pangkajene Dan Kepulauan', 'Kabupaten Pinrang', 'Kabupaten Sidenreng Rappang',
            'Kabupaten Sinjai', 'Kabupaten Soppeng', 'Kabupaten Takalar',
            'Kabupaten Tana Toraja', 'Kabupaten Toraja Utara', 'Kabupaten Wajo',
            'Kota Makassar', 'Kota Palopo', 'Kota Pare-Pare',
        ],
        'Sulawesi Tengah' => [
            'Kabupaten Banggai', 'Kabupaten Banggai Kepulauan', 'Kabupaten Banggai Laut',
            'Kabupaten Buol', 'Kabupaten Donggala', 'Kabupaten Morowali',
            'Kabupaten Morowali Utara', 'Kabupaten Parigi Moutong', 'Kabupaten Poso',
            'Kabupaten Sigi', 'Kabupaten Tojo Una-Una', 'Kabupaten Toli-Toli',
            'Kota Palu',
        ],
        'Sulawesi Tenggara' => [
            'Kabupaten Bombana', 'Kabupaten Buton', 'Kabupaten Buton Selatan',
            'Kabupaten Buton Tengah', 'Kabupaten Buton Utara', 'Kabupaten Kolaka',
            'Kabupaten Kolaka Timur', 'Kabupaten Kolaka Utara', 'Kabupaten Konawe',
            'Kabupaten Konawe Kepulauan', 'Kabupaten Konawe Selatan', 'Kabupaten Konawe Utara',
            'Kabupaten Muna', 'Kabupaten Muna Barat', 'Kabupaten Wakatobi',
            'Kota Baubau', 'Kota Kendari',
        ],
        'Sulawesi Utara' => [
            'Kabupaten Bolaang Mongondow', 'Kabupaten Bolaang Mongondow Selatan', 'Kabupaten Bolaang Mongondow Timur',
            'Kabupaten Bolaang Mongondow Utara', 'Kabupaten Kepulauan Sangihe', 'Kabupaten Kepulauan Talaud',
            'Kabupaten Minahasa', 'Kabupaten Minahasa Selatan', 'Kabupaten Minahasa Tenggara',
            'Kabupaten Minahasa Utara', 'Kabupaten Siau Tagulandang Biaro', 'Kota Bitung',
            'Kota Kotamobagu', 'Kota Manado', 'Kota Tomohon',
        ],
        'Sumatera Barat' => [
            'Kabupaten Agam', 'Kabupaten Dharmasraya', 'Kabupaten Kepulauan Mentawai',
            'Kabupaten Lima Puluh Kota', 'Kabupaten Padang Pariaman', 'Kabupaten Pasaman',
            'Kabupaten Pasaman Barat', 'Kabupaten Pesisir Selatan', 'Kabupaten Sijunjung',
            'Kabupaten Solok', 'Kabupaten Solok Selatan', 'Kabupaten Tanah Datar',
            'Kota Bukittinggi', 'Kota Padang', 'Kota Padang Panjang',
            'Kota Pariaman', 'Kota Payakumbuh', 'Kota Sawah Lunto',
            'Kota Solok',
        ],
        'Sumatera Selatan' => [
            'Kabupaten Banyu Asin', 'Kabupaten Empat Lawang', 'Kabupaten Lahat',
            'Kabupaten Muara Enim', 'Kabupaten Musi Banyu Asin', 'Kabupaten Musi Rawas',
            'Kabupaten Musi Rawas Utara', 'Kabupaten Ogan Ilir', 'Kabupaten Ogan Komering Ilir',
            'Kabupaten Ogan Komering Ulu', 'Kabupaten Ogan Komering Ulu Selatan', 'Kabupaten Ogan Komering Ulu Timur',
            'Kabupaten Penukal Abab Lematang Ilir', 'Kota Lubuk Linggau', 'Kota Pagar Alam',
            'Kota Palembang', 'Kota Prabumulih',
        ],
        'Sumatera Utara' => [
            'Kabupaten Asahan', 'Kabupaten Batu Bara', 'Kabupaten Dairi',
            'Kabupaten Deli Serdang', 'Kabupaten Humbang Hasundutan', 'Kabupaten Karo',
            'Kabupaten Labuhan Batu', 'Kabupaten Labuhan Batu Selatan', 'Kabupaten Labuhan Batu Utara',
            'Kabupaten Langkat', 'Kabupaten Mandailing Natal', 'Kabupaten Nias',
            'Kabupaten Nias Barat', 'Kabupaten Nias Selatan', 'Kabupaten Nias Utara',
            'Kabupaten Padang Lawas', 'Kabupaten Padang Lawas Utara', 'Kabupaten Pakpak Bharat',
            'Kabupaten Samosir', 'Kabupaten Serdang Bedagai', 'Kabupaten Simalungun',
            'Kabupaten Tapanuli Selatan', 'Kabupaten Tapanuli Tengah', 'Kabupaten Tapanuli Utara',
            'Kabupaten Toba Samosir', 'Kota Binjai', 'Kota Gunungsitoli',
            'Kota Medan', 'Kota Padang Sidempuan', 'Kota Pematang Siantar',
            'Kota Sibolga', 'Kota Tanjung Balai', 'Kota Tebing Tinggi',
        ],
    ];

    /** @return array<string, string[]> */
    public static function all(): array
    {
        return self::DATA;
    }

    /** @return string[] */
    public static function kotaOf(?string $provinsi): array
    {
        return self::DATA[$provinsi ?? ''] ?? [];
    }

    public static function isValid(?string $provinsi, ?string $kota): bool
    {
        return in_array($kota, self::kotaOf($provinsi), true);
    }
}