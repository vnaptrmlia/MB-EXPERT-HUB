<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="page-header">
  <div>
    <h2>Master Perusahaan</h2>
    <div class="desc">Database perusahaan yang dapat dihubungi</div>
  </div>
  <div class="actions">
    <?php if ($isAdmin): ?>
      <button class="btn btn-primary" id="btn-add-company">+ Tambah Perusahaan</button>
    <?php endif; ?>
  </div>
</div>

<div class="table-wrap">
  <div class="table-tools">
    <div class="input-search">
      <span>🔍</span>
      <input id="search-perusahaan" placeholder="Cari nama, komoditas, kota..."/>
    </div>
    <select class="input" id="filter-komoditas"><option value="">Semua Komoditas</option></select>
    <select class="input" id="filter-status">
      <option value="">Semua Status</option>
      <?php foreach ($statusOptions as $s): ?>
        <option value="<?= esc($s) ?>"><?= esc($s) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="input" id="filter-provinsi">
      <option value="">Semua Provinsi</option>
      <?php foreach ($provinceOptions as $p): ?>
        <option value="<?= esc($p) ?>"><?= esc($p) ?></option>
      <?php endforeach; ?>
    </select>
  </div>

<div class="table-scroll">
    <table>
        <thead>
        <tr>
            <th>Kode</th><th>Nama Perusahaan</th><th>Komoditas</th><th>Alamat</th>
            <th>Kota</th><th>Provinsi</th><th>Kontak</th><th>Telepon</th>
            <th>E-mail</th><th>Status</th><th>Aksi</th>
        </tr>
        </thead>
        <tbody id="tbody-perusahaan">
        <tr><td colspan="11">Memuat data...</td></tr>
        </tbody>
    </table>
</div>

<script>
  window.COMPANY_CFG = {
    isAdmin: <?= $isAdmin ? 'true' : 'false' ?>,
    urls: {
      data:   '<?= site_url('perusahaan/data') ?>',
      store:  '<?= site_url('perusahaan/store') ?>',
      update: '<?= site_url('perusahaan/update') ?>/',
      remove: '<?= site_url('perusahaan/delete') ?>/',
    },
    csrfHeader: '<?= csrf_header() ?>',
    csrfToken:  '<?= csrf_hash() ?>',
  };
</script>
<script src="<?= base_url('assets/js/companies.js') ?>"></script>

<?= $this->endSection() ?>