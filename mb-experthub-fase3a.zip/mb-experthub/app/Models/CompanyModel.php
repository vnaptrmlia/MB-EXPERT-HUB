<?php

namespace App\Models;

use CodeIgniter\Model;

class CompanyModel extends Model
{
    protected $table            = 'companies';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    // Field yang boleh diisi lewat insert()/update() — 'id' sengaja TIDAK
    // dimasukin karena auto increment, dan 'kode' juga TIDAK dimasukin
    // manual karena bakal digenerate otomatis lewat hook (bukan dari form).
    protected $allowedFields = [
        'kode', 'name', 'komoditas', 'alamat', 'kota', 'provinsi',
        'kontak', 'telepon', 'email', 'status', 'catatan',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime'; // cocok sama kolom DATETIME created_at/updated_at
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    
    // Pilihan status yang valid — dipakai di validation rule (in_list)
    // DAN di View buat isi <select>, jadi satu sumber kebenaran, nggak
    // duplikat definisi di dua tempat.
    public const STATUS_OPTIONS = [
        'Belum Dihubungi',
        'Sudah Dihubungi',
        'Follow Up',
        'Tertarik',
        'Tidak Tertarik',
    ];

    // Mapping provinsi → kode 3 huruf, dipakai buat generate `kode`
    // di hook beforeInsert (step berikutnya) DAN buat isi <select> provinsi
    // di form (biar user milih dari daftar ini, bukan ngetik manual —
    // penting supaya string provinsi konsisten, karena LIKE 'JBR-%' di
    // query generate kode itu bergantung ke provinsi yg ejaannya presisi).
    public const PROVINCE_CODES = [
        'Aceh' => 'ACE', 'Sumatera Utara' => 'SUT', 'Sumatera Barat' => 'SUB',
        'Riau' => 'RIA', 'Kepulauan Riau' => 'KRI', 'Jambi' => 'JMB',
        'Sumatera Selatan' => 'SUS', 'Kepulauan Bangka Belitung' => 'BBL',
        'Bengkulu' => 'BEN', 'Lampung' => 'LAM', 'DKI Jakarta' => 'DKI',
        'Jawa Barat' => 'JBR', 'Jawa Tengah' => 'JTG', 'DI Yogyakarta' => 'DIY',
        'Jawa Timur' => 'JTM', 'Banten' => 'BAN', 'Bali' => 'BAL',
        'Nusa Tenggara Barat' => 'NTB', 'Nusa Tenggara Timur' => 'NTT',
        'Kalimantan Barat' => 'KBR', 'Kalimantan Tengah' => 'KTG',
        'Kalimantan Selatan' => 'KSL', 'Kalimantan Timur' => 'KTM',
        'Kalimantan Utara' => 'KUT', 'Sulawesi Utara' => 'SUL',
        'Sulawesi Tengah' => 'STG', 'Sulawesi Selatan' => 'SSL',
        'Sulawesi Tenggara' => 'STR', 'Gorontalo' => 'GOR',
        'Sulawesi Barat' => 'SBR', 'Maluku' => 'MAL', 'Maluku Utara' => 'MUT',
        'Papua' => 'PPA', 'Papua Barat' => 'PBR', 'Papua Tengah' => 'PTG',
        'Papua Pegunungan' => 'PPG', 'Papua Selatan' => 'PSL',
        'Papua Barat Daya' => 'PBD',
    ];

    protected $validationRules = [
        'name'      => 'required|max_length[200]',
        'komoditas' => 'required|max_length[150]',
        'provinsi'  => 'required',
        'status'    => 'permit_empty|in_list[Belum Dihubungi,Sudah Dihubungi,Follow Up,Tertarik,Tidak Tertarik]',
        'email'     => 'permit_empty|valid_email|max_length[150]',
        'telepon'   => 'permit_empty|max_length[30]',
    ];

    protected $validationMessages = [
        'name'      => ['required' => 'Nama perusahaan wajib diisi.'],
        'komoditas' => ['required' => 'Komoditas wajib diisi.'],
        'provinsi'  => ['required' => 'Provinsi wajib dipilih.'],
    ];

    protected $beforeInsert = ['generateKode'];
    protected $beforeUpdate = ['regenerateKodeIfProvinceChanged'];

    protected function generateKode(array $data)
    {
        $data['data']['kode'] = $this->buildKode($data['data']['provinsi'] ?? null);
        return $data;
    }

    protected function regenerateKodeIfProvinceChanged(array $data)
    {
        // Kalau field 'provinsi' nggak ada di data yang diupdate, kode nggak
        // perlu disentuh sama sekali (guard ini jaga-jaga kalau nanti ada
        // endpoint update parsial, meski controller kita sekarang selalu
        // kirim 'provinsi').
        if (! array_key_exists('provinsi', $data['data'] ?? [])) {
            return $data;
        }

        $newProvinsi = $data['data']['provinsi'];
        $id          = $data['id'][0] ?? null; // beforeUpdate selalu kasih 'id' sbg array
        $existing    = $this->find($id);

        // Kalau provinsi barunya SAMA aja kayak yang lama, kode nggak usah diubah
        // (nggak worth query cari nomor urut baru buat hal yang sama).
        if ($existing === null || $existing['provinsi'] === $newProvinsi) {
            return $data;
        }

        $data['data']['kode'] = $this->buildKode($newProvinsi);
        return $data;
    }

// Logic inti generate kode, dipakai bareng insert & update (DRY)
    private function buildKode(?string $provinsi): string
    {
        $prefix = self::PROVINCE_CODES[$provinsi] ?? null;

        if ($prefix === null) {
            throw new \RuntimeException("Provinsi '{$provinsi}' tidak dikenali, kode tidak bisa digenerate.");
        }

        $last = $this->like('kode', $prefix . '-', 'after')
                    ->orderBy('kode', 'DESC')
                    ->first();

        $nextNumber = 1;
        if ($last !== null) {
            $lastNumber = (int) substr($last['kode'], strlen($prefix) + 1);
            $nextNumber = $lastNumber + 1;
        }

        return $prefix . '-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    }
}