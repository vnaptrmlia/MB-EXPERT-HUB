<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('/login', 'AuthController::loginForm');
$routes->post('/login', 'AuthController::login');
$routes->get('/logout', 'AuthController::logout');
$routes->get('dashboard', 'DashboardController::index', ['filter' => 'role']);
$routes->get('perusahaan', 'CompanyController::index', ['filter' => 'role']);
$routes->get('perusahaan/data', 'CompanyController::data', ['filter' => 'role']);


$routes->get('/dashboard', static function () {
    $user = session()->get('name') ?? 'Guest';
    return "Halo, {$user}! Login sukses. (Halaman dashboard asli nanti di Fase 3)";
}, ['filter' => 'role']);

// $routes->get('/test-admin-only', static function () {
//     return "Kamu Admin, boleh masuk sini.";
// }, ['filter' => 'role:documents']);