(function () {
  const cfg = window.COMPANY_CFG;
  let companies = [];

  const $ = (id) => document.getElementById(id);

  const STATUS_CLASS = {
    'Belum Dihubungi': 'b-gray',
    'Sudah Dihubungi': 'b-success',
    'Follow Up':       'b-warning',
    'Tertarik':        'b-info',
    'Tidak Tertarik':  'b-danger',
  };

  // Escape HTML: WAJIB tiap nyisipin data user ke innerHTML,
  // kalau tidak, nama perusahaan berisi <script> bisa jalan (XSS).
  function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function toast(title, msg, type = 'success') {
    const icons = { success: '✓', error: '✕', warning: '!' };
    const div = document.createElement('div');
    div.className = 'toast t-' + type;
    div.innerHTML =
      `<div class="icon">${icons[type] || 'ℹ'}</div>` +
      `<div class="body"><div class="title">${esc(title)}</div><div class="msg">${esc(msg)}</div></div>`;
    $('toast-host').appendChild(div);
    setTimeout(() => div.remove(), 3200);
  }

  const openModal  = (id) => $(id).classList.add('open');
  const closeModal = (id) => $(id).classList.remove('open');

  // Ekspos ke step 3b (file yang sama, dilanjut di bawah)
  window.CompanyUI = { cfg, $, esc, toast, openModal, closeModal, STATUS_CLASS,
    getCompanies: () => companies, reload: loadData };

  /* ---------- Ambil data dari server ---------- */
  async function loadData() {
    try {
      const res = await fetch(cfg.urls.data, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      companies = json.data || [];
      fillKomoditasFilter();
      render();
    } catch (e) {
      $('tbody-perusahaan').innerHTML =
        '<tr><td colspan="11">Gagal memuat data. Coba refresh halaman.</td></tr>';
      console.error(e);
    }
  }

  /* ---------- Filter komoditas (dinamis dari data) ---------- */
  function fillKomoditasFilter() {
    const sel = $('filter-komoditas');
    const cur = sel.value;
    const vals = [...new Set(companies.map((c) => c.komoditas).filter(Boolean))].sort();
    sel.innerHTML = '<option value="">Semua Komoditas</option>' +
      vals.map((v) => `<option>${esc(v)}</option>`).join('');
    sel.value = vals.includes(cur) ? cur : '';
  }

  /* ---------- Render tabel ---------- */
  function render() {
    const q  = $('search-perusahaan').value.toLowerCase();
    const fk = $('filter-komoditas').value;
    const fs = $('filter-status').value;
    const fp = $('filter-provinsi').value;

    const list = companies.filter((c) => {
      if (fk && c.komoditas !== fk) return false;
      if (fs && c.status !== fs) return false;
      if (fp && c.provinsi !== fp) return false;
      if (q) {
        const hay = [c.kode, c.name, c.komoditas, c.alamat, c.kota,
                     c.provinsi, c.kontak, c.email, c.telepon].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const tb = $('tbody-perusahaan');
    if (list.length === 0) {
      tb.innerHTML = '<tr><td colspan="11">' +
        (companies.length ? 'Tidak ada perusahaan yang cocok dengan filter.'
                          : 'Belum ada perusahaan.') + '</td></tr>';
      return;
    }

    tb.innerHTML = list.map((c) => `
      <tr>
        <td data-th="Kode"><span style="font-family:var(--font-mono);font-size:12px">${esc(c.kode)}</span></td>
        <td data-th="Nama"><div style="font-weight:600;min-width:140px">${esc(c.name)}</div></td>
        <td data-th="Komoditas">${c.komoditas ? `<span class="badge b-purple">${esc(c.komoditas)}</span>` : '-'}</td>
        <td data-th="Alamat"><div style="min-width:160px;max-width:220px;white-space:normal">${esc(c.alamat || '-')}</div></td>
        <td data-th="Kota">${esc(c.kota || '-')}</td>
        <td data-th="Provinsi">${esc(c.provinsi || '-')}</td>
        <td data-th="Kontak">${esc(c.kontak || '-')}</td>
        <td data-th="Telepon" style="white-space:nowrap">${esc(c.telepon || '-')}</td>
        <td data-th="E-mail">${c.email ? `<a href="mailto:${esc(c.email)}" style="color:inherit">${esc(c.email)}</a>` : '-'}</td>
        <td data-th="Status"><span class="badge ${STATUS_CLASS[c.status] || 'b-gray'}">${esc(c.status || '-')}</span></td>
        <td data-th="Aksi"><div class="row-actions">
          <button title="Detail" data-act="view" data-id="${c.id}">👁</button>
          ${cfg.isAdmin ? `
            <button title="Edit" data-act="edit" data-id="${c.id}">✎</button>
            <button title="Hapus" class="danger" data-act="delete" data-id="${c.id}">🗑</button>` : ''}
        </div></td>
      </tr>`).join('');
  }

  /* ---------- Event binding ---------- */
  ['search-perusahaan', 'filter-komoditas', 'filter-status', 'filter-provinsi']
    .forEach((id) => $(id).addEventListener('input', render));

  // Tutup modal: tombol [data-close], klik area gelap, tombol Esc
  document.addEventListener('click', (e) => {
    const closer = e.target.closest('[data-close]');
    if (closer) closeModal(closer.dataset.close);
    if (e.target.classList.contains('modal-backdrop')) e.target.classList.remove('open');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape')
      document.querySelectorAll('.modal-backdrop.open').forEach((m) => m.classList.remove('open'));
  });

  loadData();
  // ---- lanjut di step 3b: klik tombol aksi, form, simpan, hapus ----
})();